<?php
require __DIR__ . '/config.php';
date_default_timezone_set(PH_TIMEZONE);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

class ApiError extends Exception {}
function fail($code, $msg){ throw new ApiError($msg, $code); }
function send($code, $obj){ http_response_code($code); echo json_encode($obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function emptyObj(){ return new stdClass(); }

/* ---------- database ---------- */
function db(){
  static $pdo = null;
  if ($pdo) return $pdo;
  try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, array(
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false));
  } catch (PDOException $e) {
    error_log('PetalHub DB connect: ' . $e->getMessage());
    $driverCode = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
    if ($driverCode === 1045) fail(500, 'MySQL rejected the configured credentials. Check DB_HOST, DB_PORT, DB_USER and DB_PASS in config.php.');
    if ($driverCode === 1049) fail(500, 'The petalhub database does not exist. Import schema.sql in phpMyAdmin, then check config.php.');
    fail(500, 'Cannot connect to the MySQL database. In XAMPP start MySQL, import schema.sql in phpMyAdmin, and check config.php.');
  }
  $pdo->exec("SET time_zone = '" . date('P') . "'"); // keep MySQL NOW() and PHP on the same clock
  return $pdo;
}
function q($sql, $args = array()){ $st = db()->prepare($sql); $st->execute($args); return $st; }
function rows($sql, $args = array()){ return q($sql, $args)->fetchAll(); }
function row($sql, $args = array()){ $r = q($sql, $args)->fetch(); return $r ? $r : null; }
function marks($n){ return implode(',', array_fill(0, $n, '?')); }
define('PCOLS', 'id, name, description, price, qty, unit, sold, available, image_path'); // the columns of a flower that the website receives
// A person's name is stored as fname / mname / lname. The website still receives one "name" text, built here.
function nameSql($a){ return "CONCAT_WS(' ', NULLIF($a.fname,''), NULLIF($a.mname,''), NULLIF($a.lname,''))"; }
function fullName($r){ return trim(preg_replace('/\s+/', ' ', $r['fname'] . ' ' . $r['mname'] . ' ' . $r['lname'])); }
function splitName($full){
  $t = preg_split('/\s+/', trim((string)$full), -1, PREG_SPLIT_NO_EMPTY); $n = count($t);
  if ($n === 0) return array('', '', '');
  if ($n === 1) return array($t[0], '', '');
  if ($n === 2) return array($t[0], '', $t[1]);
  return array($t[0], implode(' ', array_slice($t, 1, $n - 2)), $t[$n - 1]);
}

/* ---------- small helpers ---------- */
function body($max = 100000){
  $raw = file_get_contents('php://input');
  if (strlen($raw) > $max) fail(413, 'That upload is too large. Please choose a smaller image.');
  if ($raw === '' || $raw === false) return array();
  $j = json_decode($raw, true);
  if (!is_array($j)) fail(400, 'Invalid JSON.');
  return $j;
}
function cut($s, $n){ return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n); }
function lower($s){ return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
function str($v, $n){ return is_string($v) ? cut(trim($v), $n) : ''; }
function isInt($v){ return is_int($v) || (is_float($v) && floor($v) == $v); }
function isNum($v){ return is_int($v) || is_float($v); }
function get($a, $k, $d = null){ return is_array($a) && array_key_exists($k, $a) ? $a[$k] : $d; }
function iso($dt){ return gmdate('Y-m-d\TH:i:s', strtotime($dt)) . '.000Z'; }

/* ---------- passwords ---------- */
// New hashes are PBKDF2 ("p2:..."). Accounts made by the old Node version used scrypt; those still work when PHP's sodium
// extension is available, and are upgraded to PBKDF2 the first time the person logs in.
function hashPw($pw, $salt){ return 'p2:' . hash_pbkdf2('sha256', $pw, $salt, 120000, 64, false); }
function checkHash($stored, $pw, $salt){
  if ($stored === null || $stored === '') return false;
  if (substr($stored, 0, 3) === 'p2:') return hash_equals($stored, hashPw($pw, $salt));
  if (function_exists('sodium_crypto_pwhash_scryptsalsa208sha256') && strlen($salt) === 32){
    try { return hash_equals($stored, bin2hex(sodium_crypto_pwhash_scryptsalsa208sha256(64, $pw, $salt, 524288, 16777216))); } catch (Exception $e) { return false; }
  }
  return false;
}
function newSalt(){ return bin2hex(random_bytes(16)); }
function addUser($fname, $mname, $lname, $email, $pw, $role){
  $salt = newSalt();
  q('INSERT INTO users (fname, mname, lname, email, salt, password_hash, role) VALUES (?,?,?,?,?,?,?)', array($fname, $mname, $lname, $email, $salt, hashPw($pw, $salt), $role));
  return (int)db()->lastInsertId();
}

function seedDeliveryRiders(){
  $lock = row("SELECT GET_LOCK('petalhub_seed_riders', 30) AS l");
  if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not initialize delivery riders. Please try again.');
  try {
    $seeds = array(
      array('Alvin', 'Jay', 'Ornejo', '09123456789'),
      array('Ynzo', 'Martin', 'Pasaoa', '09123456788'),
      array('Aldrin', '', 'Magalang', '09696710101')
    );
    $existingPhones = array_map(function($rider){ return preg_replace('/\\D/', '', $rider['phone']); }, rows('SELECT phone FROM delivery_riders'));
    foreach ($seeds as $rider){
      if (in_array($rider[3], $existingPhones, true)) continue;
      q('INSERT IGNORE INTO delivery_riders (fname, mname, lname, phone) VALUES (?, ?, ?, ?)', $rider);
      $existingPhones[] = $rider[3];
    }
  } finally {
    q("SELECT RELEASE_LOCK('petalhub_seed_riders')");
  }
}

/* ---------- GCash payment helpers (QR code, proof of payment) ---------- */
function paymentDir($sub = ''){
  $d = __DIR__ . '/payments' . ($sub !== '' ? '/' . $sub : '');
  if (!is_dir($d)) @mkdir($d, 0775, true);
  return $d;
}
// uploaded files can never be run as PHP, and payment proofs can never be opened by a direct link
function protectPaymentDirs(){
  $a = paymentDir(); $b = paymentDir('proofs');
  if (is_dir($a) && !is_file($a . '/.htaccess')) @file_put_contents($a . '/.htaccess', "<FilesMatch \"\\.(php|phtml|phar)$\">\n  Require all denied\n</FilesMatch>\n");
  if (is_dir($b) && !is_file($b . '/.htaccess')) @file_put_contents($b . '/.htaccess', "Require all denied\n");
}
function decodeImage($dataUrl, $maxBytes){
  if (!is_string($dataUrl) || !preg_match('#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\r\n]+)$#', $dataUrl, $m)) fail(400, 'Please upload a PNG, JPG or WebP image.');
  $bin = base64_decode($m[2], true);
  if ($bin === false || strlen($bin) < 100) fail(400, 'That image could not be read.');
  if (strlen($bin) > $maxBytes) fail(400, 'That image is too large. Please choose one under ' . round($maxBytes / 1000000, 1) . ' MB.');
  $info = @getimagesizefromstring($bin);
  $types = array(IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg');
  if (defined('IMAGETYPE_WEBP')) $types[IMAGETYPE_WEBP] = 'webp';
  if (!$info || !isset($types[$info[2]])) fail(400, 'That file is not a valid image.');
  return array('bin' => $bin, 'ext' => $types[$info[2]], 'mime' => $info['mime']);
}
function paymentSettings(){
  $o = array('gcash_name' => 'PetalHub Flower Shop', 'gcash_number' => '', 'gcash_qr' => 'payments/gcash-qr.png');
  foreach (rows("SELECT setting_key, setting_value FROM petalhub_settings WHERE setting_key IN ('gcash_name','gcash_number','gcash_qr')") as $r) $o[$r['setting_key']] = $r['setting_value'];
  $file = __DIR__ . '/' . $o['gcash_qr'];
  if (!is_file($file)){ $o['gcash_qr'] = 'payments/gcash-qr.png'; $file = __DIR__ . '/payments/gcash-qr.png'; }
  return array('name' => $o['gcash_name'], 'number' => $o['gcash_number'], 'qr' => $o['gcash_qr'] . (is_file($file) ? '?v=' . filemtime($file) : ''), 'hasQr' => is_file($file));
}
// put the stems of a cancelled order back on the shelf (and put a flower that sold out back on sale)
function returnStock($code){
  foreach (rows('SELECT product_id, qty FROM order_items WHERE order_code = ?', array($code)) as $it)
    q('UPDATE products SET available = IF(qty = 0, 1, available), qty = qty + ?, sold = GREATEST(sold - ?, 0) WHERE id = ?', array($it['qty'], $it['qty'], $it['product_id']));
}

/* ---------- first-run setup (checks the tables, upgrades an older database, creates the admin account) ---------- */
function hasTable($t){ return (bool)row('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', array($t)); }
function hasCol($t, $c){ return (bool)row('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', array($t, $c)); }
function hasKey($t, $k){ return (bool)row('SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?', array($t, $k)); }
function hasFkTo($t, $ref){ return (bool)row('SELECT 1 FROM information_schema.REFERENTIAL_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = ? AND REFERENCED_TABLE_NAME = ?', array($t, $ref)); }
// one schema change that is allowed to fail (for example a UNIQUE key when old data already has duplicates): it is logged and the page keeps working
function tryDdl($sql){ try { q($sql); return true; } catch (PDOException $e) { error_log('PetalHub setup: ' . $e->getMessage() . ' [' . $sql . ']'); return false; } }
function addCol($t, $c, $def){
  if (hasCol($t, $c)) return false;
  try { q('ALTER TABLE ' . $t . ' ADD COLUMN ' . $c . ' ' . $def); return true; }
  catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1060) throw $e; return false; } // 1060 = column already exists
}
// rows that every working database must have (INSERT IGNORE: existing rows are never changed)
function seedLookups(){
  q("INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES ('weather',''), ('gcash_name','PetalHub Flower Shop'), ('gcash_number',''), ('gcash_qr','payments/gcash-qr.png')");
  q("INSERT IGNORE INTO events (event_id, name) VALUES ('valentines','Valentine''s Day'), ('christmas','Christmas'), ('newyear','New Year''s Day'), ('mothersday','Mother''s Day'), ('halloween','Halloween')");
  q("INSERT IGNORE INTO weathers (weather_id, name) VALUES ('sunny','Sunny'), ('rainy','Rainy')");
  seedDeliveryRiders();
}
// move the old comma-separated flower_ids lists (event_flowers / weather_flowers) into the junction tables
function copyPicks($oldTable, $parentTable, $parentCol, $junction){
  $valid = array();
  foreach (rows('SELECT id FROM products') as $p) $valid[(int)$p['id']] = true;
  foreach (rows('SELECT ' . $parentCol . ' AS pid, flower_ids FROM ' . $oldTable) as $old){
    q('INSERT IGNORE INTO ' . $parentTable . ' (' . $parentCol . ', name) VALUES (?, ?)', array($old['pid'], ucfirst($old['pid'])));
    foreach (explode(',', (string)$old['flower_ids']) as $one){
      $one = (int)trim($one);
      if ($one > 0 && isset($valid[$one])) q('INSERT IGNORE INTO ' . $junction . ' (' . $parentCol . ', product_id) VALUES (?, ?)', array($old['pid'], $one));
    }
  }
  q('DROP TABLE ' . $oldTable);
}
// brings a database made by the earlier version of PetalHub up to the current schema (a fresh import of schema.sql is already current)
function upgradeSchema(){
  q("CREATE TABLE IF NOT EXISTS petalhub_settings (setting_key VARCHAR(40) PRIMARY KEY, setting_value VARCHAR(100) NOT NULL)");
  q("CREATE TABLE IF NOT EXISTS addresses (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, street VARCHAR(200) NOT NULL, city VARCHAR(100) NOT NULL, zip VARCHAR(20) NOT NULL DEFAULT '', contact_phone VARCHAR(30) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)");
  q("CREATE TABLE IF NOT EXISTS events (event_id VARCHAR(40) PRIMARY KEY, name VARCHAR(60) NOT NULL)");
  q("CREATE TABLE IF NOT EXISTS event_products (id INT AUTO_INCREMENT PRIMARY KEY, event_id VARCHAR(40) NOT NULL, product_id INT NOT NULL, UNIQUE KEY uq_event_product (event_id, product_id), FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE, FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE)");
  q("CREATE TABLE IF NOT EXISTS weathers (weather_id VARCHAR(20) PRIMARY KEY, name VARCHAR(40) NOT NULL)");
  q("CREATE TABLE IF NOT EXISTS weather_products (id INT AUTO_INCREMENT PRIMARY KEY, weather_id VARCHAR(20) NOT NULL, product_id INT NOT NULL, UNIQUE KEY uq_weather_product (weather_id, product_id), FOREIGN KEY (weather_id) REFERENCES weathers(weather_id) ON DELETE CASCADE, FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE)");
  q("CREATE TABLE IF NOT EXISTS delivery_riders (id INT AUTO_INCREMENT PRIMARY KEY, fname VARCHAR(40) NOT NULL, mname VARCHAR(40) NOT NULL DEFAULT '', lname VARCHAR(40) NOT NULL DEFAULT '', phone VARCHAR(30) NOT NULL, active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");

  // names: one "name" column becomes fname / mname / lname (first word, middle words, last word)
  foreach (array('users', 'delivery_riders') as $t){
    addCol($t, 'fname', "VARCHAR(40) NOT NULL DEFAULT '' AFTER id");
    addCol($t, 'mname', "VARCHAR(40) NOT NULL DEFAULT '' AFTER fname");
    addCol($t, 'lname', "VARCHAR(40) NOT NULL DEFAULT '' AFTER mname");
    if (hasCol($t, 'name')){
      foreach (rows('SELECT id, name FROM ' . $t) as $one){
        $n = splitName($one['name']);
        q('UPDATE ' . $t . ' SET fname = ?, mname = ?, lname = ? WHERE id = ?', array(cut($n[0], 40), cut($n[1], 40), cut($n[2], 40), $one['id']));
      }
      q('ALTER TABLE ' . $t . ' DROP COLUMN name');
    }
  }
  if (!hasKey('delivery_riders', 'uq_riders_name')) tryDdl('ALTER TABLE delivery_riders ADD UNIQUE KEY uq_riders_name (fname, mname, lname)');

  // products: sold counter and UNIQUE name
  addCol('products', 'active', 'TINYINT(1) NOT NULL DEFAULT 1');
  addCol('products', 'description', "VARCHAR(300) NOT NULL DEFAULT ''");
  addCol('products', 'image_path', "VARCHAR(255) NOT NULL DEFAULT ''");
  addCol('products', 'available', 'TINYINT(1) NOT NULL DEFAULT 1');
  if (addCol('products', 'sold', 'INT NOT NULL DEFAULT 0'))
    q("UPDATE products p SET p.sold = COALESCE((SELECT SUM(oi.qty) FROM order_items oi JOIN orders o ON o.code = oi.order_code WHERE oi.product_id = p.id AND o.status <> 'Cancelled'), 0)");
  if (!hasKey('products', 'uq_products_name')) tryDdl('ALTER TABLE products ADD UNIQUE KEY uq_products_name (name)');

  // orders: delivery address moves to the addresses table, the rider's name and phone are read from delivery_riders
  addCol('orders', 'checkout_key', 'VARCHAR(60) NULL');
  addCol('orders', 'rider_id', 'INT NULL');
  addCol('orders', 'payment_status', "VARCHAR(20) NOT NULL DEFAULT 'not_required'");
  addCol('orders', 'gcash_ref', 'VARCHAR(30) NULL');
  addCol('orders', 'payment_proof', "VARCHAR(160) NOT NULL DEFAULT ''");
  addCol('orders', 'payment_note', "VARCHAR(200) NOT NULL DEFAULT ''");
  addCol('orders', 'paid_at', 'DATETIME NULL');
  addCol('orders', 'address_id', 'INT NULL');
  if (hasCol('orders', 'street')){
    foreach (rows("SELECT code, user_id, street, city, zip, customer_phone FROM orders WHERE address_id IS NULL AND fulfillment = 'delivery'") as $o){
      $a = row('SELECT id FROM addresses WHERE user_id = ? AND street = ? AND city = ? AND zip = ? AND contact_phone = ? ORDER BY id LIMIT 1', array($o['user_id'], $o['street'], $o['city'], $o['zip'], $o['customer_phone']));
      if ($a) $addressId = (int)$a['id'];
      else {
        q('INSERT INTO addresses (user_id, street, city, zip, contact_phone) VALUES (?,?,?,?,?)', array($o['user_id'], $o['street'], $o['city'], $o['zip'], $o['customer_phone']));
        $addressId = (int)db()->lastInsertId();
      }
      q('UPDATE orders SET address_id = ? WHERE code = ?', array($addressId, $o['code']));
    }
  }
  foreach (array('street', 'city', 'zip', 'customer_phone', 'rider_name', 'rider_phone') as $c)
    if (hasCol('orders', $c)) q('ALTER TABLE orders DROP COLUMN ' . $c);
  q("UPDATE orders SET payment_status = 'not_required' WHERE payment_status NOT IN ('not_required','awaiting','verified','rejected')");
  q("ALTER TABLE orders MODIFY payment_status ENUM('not_required','awaiting','verified','rejected') NOT NULL DEFAULT 'not_required'");
  q('UPDATE orders SET rider_id = NULL WHERE rider_id IS NOT NULL AND rider_id NOT IN (SELECT id FROM delivery_riders)');
  if (!hasFkTo('orders', 'addresses')) tryDdl('ALTER TABLE orders ADD CONSTRAINT fk_orders_address FOREIGN KEY (address_id) REFERENCES addresses(id)');
  if (!hasFkTo('orders', 'delivery_riders')) tryDdl('ALTER TABLE orders ADD CONSTRAINT fk_orders_rider FOREIGN KEY (rider_id) REFERENCES delivery_riders(id) ON DELETE SET NULL');
  if (!hasKey('orders', 'uq_orders_gcash_ref')) tryDdl('ALTER TABLE orders ADD UNIQUE KEY uq_orders_gcash_ref (gcash_ref)');
  if (!hasKey('orders', 'uq_orders_user_key')) tryDdl('ALTER TABLE orders ADD UNIQUE KEY uq_orders_user_key (user_id, checkout_key)');
  if (hasCol('order_items', 'name')) q('ALTER TABLE order_items DROP COLUMN name'); // the flower's name is read from products

  // recommendations: the comma-separated lists become rows in the junction tables
  q("INSERT IGNORE INTO events (event_id, name) VALUES ('valentines','Valentine''s Day'), ('christmas','Christmas'), ('newyear','New Year''s Day'), ('mothersday','Mother''s Day'), ('halloween','Halloween')");
  q("INSERT IGNORE INTO weathers (weather_id, name) VALUES ('sunny','Sunny'), ('rainy','Rainy')");
  if (hasTable('event_flowers')) copyPicks('event_flowers', 'events', 'event_id', 'event_products');
  if (hasTable('weather_flowers')) copyPicks('weather_flowers', 'weathers', 'weather_id', 'weather_products');
}
function ensureSetup(){
  // an admin made by the old Node version can only be read when PHP has the sodium extension; otherwise reset it to config.php's password
  if (!function_exists('sodium_crypto_pwhash_scryptsalsa208sha256')){ $sl = newSalt(); q("UPDATE users SET salt = ?, password_hash = ? WHERE role = 'admin' AND password_hash NOT LIKE 'p2:%'", array($sl, hashPw(ADMIN_PASSWORD, $sl))); }
  $check = "SELECT (SELECT COUNT(*) FROM users WHERE role = 'admin') AS a,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND (
                      (TABLE_NAME = 'users' AND COLUMN_NAME IN ('fname','mname','lname')) OR
                      (TABLE_NAME = 'delivery_riders' AND COLUMN_NAME IN ('fname','mname','lname')) OR
                      (TABLE_NAME = 'orders' AND COLUMN_NAME IN ('address_id','rider_id','checkout_key','payment_status','gcash_ref','payment_proof','payment_note','paid_at')) OR
                      (TABLE_NAME = 'products' AND COLUMN_NAME IN ('sold','available','image_path','description','active')))) AS good_cols,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND (
                      (TABLE_NAME = 'users' AND COLUMN_NAME = 'name') OR
                      (TABLE_NAME = 'delivery_riders' AND COLUMN_NAME = 'name') OR
                      (TABLE_NAME = 'order_items' AND COLUMN_NAME = 'name') OR
                      (TABLE_NAME = 'orders' AND COLUMN_NAME IN ('street','city','zip','customer_phone','rider_name','rider_phone')))) AS old_cols,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('addresses','events','event_products','weathers','weather_products','delivery_riders','petalhub_settings')) AS good_tables,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('event_flowers','weather_flowers')) AS old_tables,
                   (SELECT COUNT(DISTINCT INDEX_NAME) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME IN ('uq_orders_user_key','uq_orders_gcash_ref')) AS keys_ok";
  $ready = function($s){ return $s['a'] > 0 && $s['good_cols'] == 19 && $s['old_cols'] == 0 && $s['good_tables'] == 7 && $s['old_tables'] == 0 && $s['keys_ok'] == 2; };
  try { $s = row($check); }
  catch (PDOException $e) {
    if (isset($e->errorInfo[1]) && $e->errorInfo[1] == 1146) fail(500, 'The database tables are missing. Import schema.sql in phpMyAdmin (see README.md).');
    throw $e;
  }
  if ($ready($s)){ seedLookups(); return; }
  // Several requests can arrive at the same moment on the very first page load: only one of them may run the setup.
  $lock = row("SELECT GET_LOCK('petalhub_setup', 30) AS l");
  try {
    $s = row($check); // look again now that we hold the lock; another request may have finished the setup already
    if ($ready($s)){ seedLookups(); return; }
    upgradeSchema();
    if (!$s['a']){
      try { addUser('Admin', '', '', strtolower(ADMIN_EMAIL), ADMIN_PASSWORD, 'admin'); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1062) throw $e; } // 1062 = admin already exists
    }
    seedLookups();
  } finally {
    q("SELECT RELEASE_LOCK('petalhub_setup')");
  }
}

/* ---------- login sessions ---------- */
function bearer(){
  if (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) return $_SERVER['HTTP_X_AUTH_TOKEN'];
  $a = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '');
  if ($a === '' && function_exists('getallheaders')) foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $a = $v;
  return preg_match('/^Bearer (.+)$/', $a, $m) ? $m[1] : '';
}
function authUser(){
  $t = bearer(); if ($t === '') return null;
  return row('SELECT u.id, ' . nameSql('u') . ' AS name, u.email, u.role FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > NOW()', array(hash('sha256', $t)));
}
function startSession($u){
  $t = bin2hex(random_bytes(24));
  q('DELETE FROM sessions WHERE expires_at < NOW()');
  q('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))', array(hash('sha256', $t), $u['id']));
  send(200, array('token' => $t, 'user' => array('name' => $u['name'], 'email' => $u['email'], 'role' => $u['role'])));
}
// at most 10 login / register attempts per visitor per 5 minutes
function throttled(){
  $f = sys_get_temp_dir() . '/petalhub_throttle_' . md5(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0') . '.json';
  $fh = @fopen($f, 'c+'); if (!$fh) return false;
  flock($fh, LOCK_EX);
  $now = time(); $t = array('n' => 0, 'reset' => $now + 300);
  $d = json_decode((string)stream_get_contents($fh), true);
  if (is_array($d) && isset($d['reset']) && $d['reset'] > $now) $t = $d;
  $t['n']++;
  ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($t));
  flock($fh, LOCK_UN); fclose($fh);
  return $t['n'] > 10;
}

/* ---------- shaping rows for the website ---------- */
function pub($p){
  $qty = (int)$p['qty']; $on = $qty > 0 && (!isset($p['available']) || (int)$p['available'] === 1);
  return array('id' => (int)$p['id'], 'name' => isset($p['name']) ? $p['name'] : '', 'desc' => isset($p['description']) ? $p['description'] : '', 'price' => (float)$p['price'],
    'qty' => $qty, 'sold' => isset($p['sold']) ? (int)$p['sold'] : 0, 'unit' => $p['unit'], 'available' => $on, 'imagePath' => isset($p['image_path']) ? $p['image_path'] : '',
    'stock' => ($on && $qty > 0) ? $qty . ' ' . $p['unit'] : 'Out of stock');
}
function toOrders($rs){
  if (!$rs) return array();
  $codes = array_map(function($r){ return $r['code']; }, $rs);
  $items = rows('SELECT oi.order_code, oi.product_id AS id, p.name, oi.qty, oi.price, oi.line_key, oi.line_name, oi.arrangement, oi.line_qty, oi.wrap_design, oi.wrap_color, oi.wrap_notes, oi.wrap_fee FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_code IN (' . marks(count($codes)) . ') ORDER BY oi.id', $codes);
  $out = array();
  foreach ($rs as $r){
    $mine = array();
    foreach ($items as $i) if ($i['order_code'] === $r['code']) $mine[] = array(
      'id' => (int)$i['id'], 'name' => $i['name'], 'qty' => (int)$i['qty'], 'price' => (float)$i['price'],
      'lineKey' => $i['line_key'], 'lineName' => $i['line_name'], 'arrangement' => $i['arrangement'],
      'lineQty' => (int)$i['line_qty'], 'wrapDesign' => $i['wrap_design'], 'wrapColor' => $i['wrap_color'],
      'wrapNotes' => $i['wrap_notes'], 'wrapFee' => (float)$i['wrap_fee']);
    $out[] = array('code' => $r['code'], 'date' => iso($r['created_at']), 'customer' => $r['customer'], 'email' => $r['email'], 'total' => (float)$r['total'], 'status' => $r['status'],
      'items' => $mine, 'fulfillment' => $r['fulfillment'], 'address' => array('street' => $r['street'], 'city' => $r['city'], 'zip' => $r['zip']),
      'customerPhone' => isset($r['customer_phone']) ? $r['customer_phone'] : '',
      'riderId' => isset($r['rider_id']) && $r['rider_id'] !== null ? (int)$r['rider_id'] : null,
      'riderName' => isset($r['rider_name']) ? $r['rider_name'] : '', 'riderPhone' => isset($r['rider_phone']) ? $r['rider_phone'] : '',
      'payment' => $r['payment'],
      'paymentStatus' => isset($r['payment_status']) ? $r['payment_status'] : 'not_required',
      'gcashRef' => isset($r['gcash_ref']) ? $r['gcash_ref'] : null,
      'hasProof' => !empty($r['payment_proof']),
      'paymentNote' => isset($r['payment_note']) ? $r['payment_note'] : '',
      'paidAt' => !empty($r['paid_at']) ? iso($r['paid_at']) : null);
  }
  return $out;
}
// orders with the customer's name, delivery address and rider read from their own tables
function orderRows($where, $args = array()){
  return toOrders(rows("SELECT o.*, " . nameSql('u') . " AS customer, u.email, COALESCE(a.street, '') AS street, COALESCE(a.city, '') AS city, COALESCE(a.zip, '') AS zip, COALESCE(a.contact_phone, '') AS customer_phone, " . nameSql('r') . " AS rider_name, COALESCE(r.phone, '') AS rider_phone FROM orders o JOIN users u ON u.id = o.user_id LEFT JOIN addresses a ON a.id = o.address_id LEFT JOIN delivery_riders r ON r.id = o.rider_id " . $where . " ORDER BY o.created_at DESC, o.code DESC", $args));
}
// replace the flowers picked for one event or weather (the many-to-many junction tables)
function setPicks($table, $col, $parentId, $ids){
  inTx(function() use ($table, $col, $parentId, $ids){
    q('DELETE FROM ' . $table . ' WHERE ' . $col . ' = ?', array($parentId));
    foreach ($ids as $pid) q('INSERT INTO ' . $table . ' (' . $col . ', product_id) VALUES (?, ?)', array($parentId, $pid));
  });
}
function inTx($fn){
  $pdo = db(); $pdo->beginTransaction();
  try { $out = $fn(); $pdo->commit(); return $out; }
  catch (Exception $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}

/* ---------- the API ---------- */
function handle(){
  $m = $_SERVER['REQUEST_METHOD'];
  $route = '/' . trim(isset($_GET['route']) ? $_GET['route'] : '', '/');
  $FLOW = array('Pending', 'Preparing', 'Ready', 'Completed');
  db(); ensureSetup();

  if ($m === 'GET' && $route === '/products')
    send(200, array_map('pub', rows('SELECT ' . PCOLS . ' FROM products WHERE active = 1 ORDER BY id')));
  if ($m === 'GET' && $route === '/merchandising'){
    $settings = array();
    foreach (rows("SELECT setting_key, setting_value FROM petalhub_settings WHERE setting_key = 'weather'") as $setting)
      $settings[$setting['setting_key']] = $setting['setting_value'];
    $events = array();
    foreach (rows('SELECT event_id FROM events') as $event) $events[$event['event_id']] = array();
    foreach (rows('SELECT event_id, product_id FROM event_products ORDER BY id') as $pick) $events[$pick['event_id']][] = (int)$pick['product_id'];
    $weatherFlowers = array();
    foreach (rows('SELECT weather_id FROM weathers') as $weather) $weatherFlowers[$weather['weather_id']] = array();
    foreach (rows('SELECT weather_id, product_id FROM weather_products ORDER BY id') as $pick) $weatherFlowers[$pick['weather_id']][] = (int)$pick['product_id'];
    send(200, array('weather' => isset($settings['weather']) && in_array($settings['weather'], array('sunny','rainy'), true) ? $settings['weather'] : '',
      'eventFlowers' => $events, 'weatherFlowers' => $weatherFlowers));
  }
  if ($m === 'GET' && $route === '/payment-info') send(200, paymentSettings());
  $me = authUser();
  if ($m === 'GET' && $route === '/me') $me ? send(200, array('user' => array('name' => $me['name'], 'email' => $me['email'], 'role' => $me['role']))) : send(401, array('error' => 'Please log in.'));
  if ($m === 'POST' && $route === '/logout'){ if (bearer() !== '') q('DELETE FROM sessions WHERE token_hash = ?', array(hash('sha256', bearer()))); send(200, emptyObj()); }

  if ($m === 'POST' && ($route === '/register' || $route === '/login')){
    if (throttled()) fail(429, 'Too many attempts. Try again in a few minutes.');
    $b = body(); $email = lower(str(get($b, 'email'), 200)); $pw = is_string(get($b, 'pass')) ? $b['pass'] : '';
    if ($route === '/login'){
      $u = row('SELECT * FROM users WHERE email = ?', array($email));
      if (!$u || !checkHash($u['password_hash'], $pw, $u['salt'])) fail(401, 'Incorrect email or password.');
      if (substr($u['password_hash'], 0, 3) !== 'p2:'){ $s = newSalt(); q('UPDATE users SET salt = ?, password_hash = ? WHERE id = ?', array($s, hashPw($pw, $s), $u['id'])); }
      $u['name'] = fullName($u);
      startSession($u);
    }
    $fname = str(get($b, 'fname'), 40); $mname = str(get($b, 'mname'), 40); $lname = str(get($b, 'lname'), 40);
    if ($fname === '' && is_string(get($b, 'name'))){ $sp = splitName(str(get($b, 'name'), 120)); $fname = cut($sp[0], 40); $mname = cut($sp[1], 40); $lname = cut($sp[2], 40); }
    $name = fullName(array('fname' => $fname, 'mname' => $mname, 'lname' => $lname));
    if ($fname === '' || $lname === '' || !preg_match('/^\S+@\S+\.\S+$/', $email)) fail(400, 'Enter your first name, last name and a valid email.');
    if (strlen($pw) < 6) fail(400, 'Password must be at least 6 characters.');
    if (row('SELECT id FROM users WHERE email = ?', array($email))) fail(409, 'An account with that email already exists. Please log in.');
    $id = addUser($fname, $mname, $lname, $email, $pw, 'customer');
    startSession(array('id' => $id, 'name' => $name, 'email' => $email, 'role' => 'customer'));
  }

  if ($m === 'GET' && $route === '/orders/mine'){
    if (!$me) fail(401, 'Please log in.');
    send(200, orderRows('WHERE o.user_id = ?', array($me['id'])));
  }

  if ($m === 'POST' && $route === '/orders'){
    if (!$me) fail(401, 'Please log in to place an order.');
    $b = body(2800000); $want = array(); $requested = array(); $lineMap = array(); $its = get($b, 'items');
    if (!is_array($its) || !count($its) || count($its) > 50) fail(400, 'Your cart is empty.');
    $wrapPrices = array('pink-elegance' => 75.00, 'classic-kraft' => 50.00, 'midnight-luxury' => 80.00, 'minimalist-white' => 45.00);
    foreach ($its as $index => $i){
      $id = get($i, 'id'); $n = get($i, 'qty');
      if (!is_numeric($id) || !is_numeric($n) || !isInt($id + 0) || !isInt($n + 0) || $n < 1 || $n > 99) fail(400, 'Invalid cart.');
      $id = (int)$id; $arrangement = get($i, 'arrangement', 'single');
      if (!in_array($arrangement, array('single', 'bouquet', 'custom'), true)) fail(400, 'Invalid arrangement.');
      $lineQty = get($i, 'line_qty', $n);
      if (!is_numeric($lineQty) || !isInt($lineQty + 0) || $lineQty < 1 || $lineQty > 99) fail(400, 'Invalid cart quantity.');
      $lineKey = str(get($i, 'line_key'), 60);
      if ($lineKey === '') $lineKey = 'legacy-' . $index;
      $wrapDesign = str(get($i, 'wrap_design'), 40);
      if ($wrapDesign !== '' && ($arrangement === 'single' || !isset($wrapPrices[$wrapDesign]))) fail(400, 'Invalid wrapping option.');
      $line = array(
        'line_key' => $lineKey,
        'line_name' => str(get($i, 'line_name'), 80),
        'arrangement' => $arrangement,
        'line_qty' => (int)$lineQty,
        'wrap_design' => $wrapDesign === '' ? null : $wrapDesign,
        'wrap_color' => str(get($i, 'wrap_color'), 100),
        'wrap_notes' => str(get($i, 'wrap_notes'), 300)
      );
      if (isset($lineMap[$lineKey]) && $lineMap[$lineKey] !== $line) fail(400, 'Invalid cart grouping.');
      $lineMap[$lineKey] = $line;
      $requested[] = array('id' => $id, 'qty' => (int)$n, 'line' => $line);
      $want[$id] = (isset($want[$id]) ? $want[$id] : 0) + (int)$n;
    }
    $f = get($b, 'fulfillment'); $delivery = $f === 'delivery';
    if (!$delivery && $f !== 'pickup') fail(400, 'Choose pickup or delivery.');
    $a = get($b, 'address', array());
    $ad = $delivery ? array('street' => str(get($a, 'street'), 200), 'city' => str(get($a, 'city'), 100), 'zip' => str(get($a, 'zip'), 20), 'phone' => str(get($a, 'phone'), 30)) : array('street' => '', 'city' => '', 'zip' => '', 'phone' => '');
    if ($delivery && ($ad['street'] === '' || $ad['city'] === '')) fail(400, 'Enter a delivery address.');
    if ($delivery && (!preg_match('/^[0-9+().\\s-]{7,30}$/', $ad['phone']) || strlen(preg_replace('/\\D/', '', $ad['phone'])) < 7)) fail(400, 'Enter a valid contact phone number for delivery.');
    $payMap = array('gcash' => 'GCash (QR)', 'cash' => $delivery ? 'Cash on delivery' : 'Cash on pickup');
    $pk = get($b, 'payment'); $pay = is_string($pk) && isset($payMap[$pk]) ? $payMap[$pk] : null;
    if (!$pay) fail(400, 'Choose a payment method.');
    // GCash QR: the customer pays by scanning the shop's QR code, then submits the 13-digit reference number from the GCash receipt.
    // The order is saved as "awaiting verification" and the admin must verify the payment before it can move forward.
    $isGcash = $pk === 'gcash'; $ref = null; $proofImage = null;
    if ($isGcash){
      $ref = preg_replace('/\D/', '', (string)get($b, 'gcashRef', ''));
      if (strlen($ref) !== 13) fail(400, 'Enter the 13-digit GCash reference number shown on your payment receipt.');
      $proofIn = get($b, 'proof');
      if (is_string($proofIn) && $proofIn !== '') $proofImage = decodeImage($proofIn, 2000000);
    }
    $key = str(get($b, 'key'), 60); if ($key === '') $key = null;
    $existing = function() use ($me, $key){ return $key ? row('SELECT code FROM orders WHERE user_id = ? AND checkout_key = ?', array($me['id'], $key)) : null; };
    try {
      $out = inTx(function() use ($want, $requested, $lineMap, $wrapPrices, $existing, $me, $f, $ad, $pay, $key, $isGcash, $ref){
        $ids = array_keys($want); sort($ids);
        $prods = rows('SELECT id, name, price, qty, available FROM products WHERE id IN (' . marks(count($ids)) . ') AND active = 1 ORDER BY id FOR UPDATE', $ids);
        $dup = $existing(); // checked again after the product lock, so two simultaneous requests cannot both pass
        if ($dup) return array('code' => $dup['code'], 'duplicate' => true);
        if ($isGcash && row('SELECT code FROM orders WHERE gcash_ref = ?', array($ref))) fail(409, 'This GCash reference number was already used for another order. Please check the number on your receipt.');
        if (count($prods) !== count($ids)) fail(400, 'Unknown product.');
        $total = 0;
        foreach ($prods as $p){
          if (!(int)$p['available']) fail(409, $p['name'] . ' is out of stock.');
          if ($want[(int)$p['id']] > $p['qty']) fail(409, $p['qty'] ? 'Only ' . $p['qty'] . ' left of ' . $p['name'] . '.' : $p['name'] . ' is out of stock.');
          $total += (float)$p['price'] * $want[(int)$p['id']];
        }
        foreach ($lineMap as $line) if ($line['wrap_design']) $total += $wrapPrices[$line['wrap_design']] * $line['line_qty'];
        $total = round($total, 2);
        do { $oc = 'PH-' . random_int(100000, 999999); } while (row('SELECT 1 FROM orders WHERE code = ?', array($oc)));
        // the delivery address lives in its own table; an address the customer already used is reused
        $addressId = null;
        if ($f === 'delivery'){
          $known = row('SELECT id FROM addresses WHERE user_id = ? AND street = ? AND city = ? AND zip = ? AND contact_phone = ? ORDER BY id LIMIT 1', array($me['id'], $ad['street'], $ad['city'], $ad['zip'], $ad['phone']));
          if ($known) $addressId = (int)$known['id'];
          else {
            q('INSERT INTO addresses (user_id, street, city, zip, contact_phone) VALUES (?,?,?,?,?)', array($me['id'], $ad['street'], $ad['city'], $ad['zip'], $ad['phone']));
            $addressId = (int)db()->lastInsertId();
          }
        }
        q('INSERT INTO orders (code, user_id, address_id, total, fulfillment, payment, checkout_key, payment_status, gcash_ref) VALUES (?,?,?,?,?,?,?,?,?)',
          array($oc, $me['id'], $addressId, $total, $f, $pay, $key, $isGcash ? 'awaiting' : 'not_required', $ref));
        $productsById = array();
        foreach ($prods as $p) $productsById[(int)$p['id']] = $p;
        $feesApplied = array();
        foreach ($requested as $item){
          $p = $productsById[$item['id']]; $line = $item['line'];
          $fee = 0;
          if (!isset($feesApplied[$line['line_key']]) && $line['wrap_design']){
            $fee = $wrapPrices[$line['wrap_design']] * $line['line_qty'];
            $feesApplied[$line['line_key']] = true;
          }
          $lineName = $line['line_name'] !== '' ? $line['line_name'] : $p['name'];
          q('INSERT INTO order_items (order_code, product_id, qty, price, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes, wrap_fee) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            array($oc, $p['id'], $item['qty'], $p['price'], $line['line_key'], $lineName, $line['arrangement'], $line['line_qty'], $line['wrap_design'], $line['wrap_color'], $line['wrap_notes'], $fee));
        }
        foreach ($prods as $p){
          $used = $want[(int)$p['id']];
          q('UPDATE products SET available = IF(qty = ?, 0, available), qty = qty - ?, sold = sold + ? WHERE id = ?', array($used, $used, $used, $p['id']));
        }
        return array('code' => $oc);
      });
    } catch (PDOException $e) {
      $dupInfo = isset($e->errorInfo[1]) && $e->errorInfo[1] == 1062;
      if ($dupInfo && strpos($e->getMessage(), 'uq_orders_gcash_ref') !== false) fail(409, 'This GCash reference number was already used for another order. Please check the number on your receipt.');
      if ($dupInfo && $key && ($dup = $existing())) $out = array('code' => $dup['code'], 'duplicate' => true);
      else throw $e;
    }
    // the proof-of-payment picture is saved after the order exists, under a random name, and can only be opened by the admin
    if ($proofImage && empty($out['duplicate'])){
      protectPaymentDirs();
      $file = $out['code'] . '-' . bin2hex(random_bytes(6)) . '.' . $proofImage['ext'];
      if (@file_put_contents(paymentDir('proofs') . '/' . $file, $proofImage['bin']) !== false) q('UPDATE orders SET payment_proof = ? WHERE code = ?', array($file, $out['code']));
    }
    $out['paymentStatus'] = $isGcash ? 'awaiting' : 'not_required';
    send(!empty($out['duplicate']) ? 200 : 201, $out);
  }

  if (strpos($route, '/admin/') === 0){
    if (!$me || $me['role'] !== 'admin') fail(403, 'Admin access only.');
    if ($m === 'GET' && $route === '/admin/orders')
      send(200, orderRows(''));
    if ($m === 'PUT' && preg_match('#^/admin/orders/(PH-\d+)/payment$#', $route, $r)){
      $code = $r[1]; $b = body(); $action = get($b, 'action'); $note = str(get($b, 'note'), 200);
      if (!in_array($action, array('verify', 'reject'), true)) fail(400, 'Choose Verify or Reject.');
      $out = inTx(function() use ($code, $action, $note){
        $o = row('SELECT status, payment_status FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$o) fail(404, 'Order not found.');
        if ($o['payment_status'] !== 'awaiting') fail(409, 'This payment has already been ' . ($o['payment_status'] === 'verified' ? 'verified.' : ($o['payment_status'] === 'rejected' ? 'rejected.' : 'handled (no GCash payment is waiting).')));
        if ($action === 'verify'){
          q("UPDATE orders SET payment_status = 'verified', paid_at = NOW(), payment_note = ? WHERE code = ?", array($note, $code));
          return array('code' => $code, 'paymentStatus' => 'verified');
        }
        if ($o['status'] === 'Cancelled') fail(409, 'This order is already cancelled.');
        returnStock($code);
        q("UPDATE orders SET payment_status = 'rejected', status = 'Cancelled', payment_note = ? WHERE code = ?", array($note !== '' ? $note : 'The GCash payment could not be verified.', $code));
        return array('code' => $code, 'paymentStatus' => 'rejected', 'status' => 'Cancelled');
      });
      send(200, $out);
    }
    if ($m === 'GET' && preg_match('#^/admin/orders/(PH-\d+)/proof$#', $route, $r)){
      $o = row('SELECT payment_proof FROM orders WHERE code = ?', array($r[1]));
      $file = $o && $o['payment_proof'] !== '' ? paymentDir('proofs') . '/' . basename($o['payment_proof']) : '';
      if ($file === '' || !is_file($file)) fail(404, 'No proof of payment was uploaded for this order.');
      $info = @getimagesize($file);
      header('Content-Type: ' . ($info && !empty($info['mime']) ? $info['mime'] : 'application/octet-stream'));
      header('Content-Length: ' . filesize($file));
      readfile($file); exit;
    }
    if ($m === 'PUT' && $route === '/admin/payment-settings'){
      $b = body(); $name = str(get($b, 'name'), 100); $number = str(get($b, 'number'), 30);
      if ($name === '') fail(400, 'Enter the name shown on the GCash account.');
      if ($number !== '' && !preg_match('/^[0-9+\s-]{7,30}$/', $number)) fail(400, 'Enter a valid GCash mobile number, for example 0917 123 4567.');
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_name', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($name));
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_number', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($number));
      send(200, paymentSettings());
    }
    if ($m === 'POST' && $route === '/admin/payment-qr'){
      $img = decodeImage(get(body(2800000), 'image'), 2000000);
      protectPaymentDirs();
      $dir = paymentDir();
      foreach (glob($dir . '/gcash-qr-custom.*') ?: array() as $old) @unlink($old);
      $path = 'payments/gcash-qr-custom.' . $img['ext'];
      if (@file_put_contents(__DIR__ . '/' . $path, $img['bin']) === false) fail(500, 'The QR image could not be saved. Check that the petalhub/payments folder can be written to.');
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_qr', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($path));
      send(200, paymentSettings());
    }
    if ($m === 'GET' && $route === '/admin/riders')
      send(200, rows('SELECT id, ' . nameSql('delivery_riders') . ' AS name, phone FROM delivery_riders WHERE active = 1 ORDER BY fname, mname, lname, id'));
    if ($m === 'POST' && $route === '/admin/riders'){
      $b = body(); $phone = str(get($b, 'phone'), 30);
      $fname = str(get($b, 'fname'), 40); $mname = str(get($b, 'mname'), 40); $lname = str(get($b, 'lname'), 40);
      if ($fname === '' && is_string(get($b, 'name'))){ $sp = splitName(str(get($b, 'name'), 120)); $fname = cut($sp[0], 40); $mname = cut($sp[1], 40); $lname = cut($sp[2], 40); }
      if ($fname === '' || $lname === '') fail(400, 'Enter the rider first name and last name.');
      $name = fullName(array('fname' => $fname, 'mname' => $mname, 'lname' => $lname));
      if (!preg_match('/^[0-9+().\\s-]{7,30}$/', $phone) || strlen(preg_replace('/\\D/', '', $phone)) < 7) fail(400, 'Enter a valid rider phone number.');
      $normalizedPhone = preg_replace('/\\D/', '', $phone);
      $lock = row("SELECT GET_LOCK('petalhub_add_rider', 30) AS l");
      if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not save the rider right now. Please try again.');
      try {
        foreach (rows('SELECT phone FROM delivery_riders WHERE active = 1') as $existingRider){
          if (preg_replace('/\\D/', '', $existingRider['phone']) === $normalizedPhone)
            fail(409, 'A rider with this phone number already exists.');
        }
        if (row('SELECT id FROM delivery_riders WHERE fname = ? AND mname = ? AND lname = ?', array($fname, $mname, $lname))) fail(409, 'A rider with this name already exists.');
        q('INSERT INTO delivery_riders (fname, mname, lname, phone) VALUES (?, ?, ?, ?)', array($fname, $mname, $lname, $phone));
        $created = array('id' => (int)db()->lastInsertId(), 'name' => $name, 'phone' => $phone);
      } finally {
        q("SELECT RELEASE_LOCK('petalhub_add_rider')");
      }
      send(201, $created);
    }
    if ($m === 'PUT' && preg_match('#^/admin/orders/(PH-\d+)/rider$#', $route, $r)){
      $code = $r[1]; $riderId = get(body(), 'riderId');
      if ($riderId !== null && (!is_int($riderId) || $riderId < 1)) fail(400, 'Choose a valid delivery rider.');
      $result = inTx(function() use ($code, $riderId){
        $order = row('SELECT fulfillment FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$order) fail(404, 'Order not found.');
        if ($order['fulfillment'] !== 'delivery') fail(400, 'A delivery rider can only be assigned to delivery orders.');
        if ($riderId === null){
          q('UPDATE orders SET rider_id = NULL WHERE code = ?', array($code));
          return array('riderId' => null, 'riderName' => '', 'riderPhone' => '');
        }
        $rider = row('SELECT id, ' . nameSql('delivery_riders') . ' AS name, phone FROM delivery_riders WHERE id = ? AND active = 1', array($riderId));
        if (!$rider) fail(404, 'Delivery rider not found.');
        q('UPDATE orders SET rider_id = ? WHERE code = ?', array($rider['id'], $code));
        return array('riderId' => (int)$rider['id'], 'riderName' => $rider['name'], 'riderPhone' => $rider['phone']);
      });
      send(200, array_merge(array('code' => $code), $result));
    }
    if ($m === 'GET' && $route === '/admin/products') send(200, array_map('pub', rows('SELECT ' . PCOLS . ' FROM products WHERE active = 1 ORDER BY id')));
    if ($m === 'POST' && $route === '/admin/products'){
      $b = body(); $nameInput = get($b, 'name'); $imageInput = get($b, 'imagePath'); $price = get($b, 'price');
      if (!is_string($nameInput) || trim($nameInput) === '' || strlen(trim($nameInput)) > 80) fail(400, 'Enter a flower name up to 80 characters.');
      if (!is_string($imageInput) || !preg_match('#^flowers/[A-Za-z0-9_.-]+\.(jpg|jpeg|png|webp|gif)$#i', $imageInput)) fail(400, 'Enter an image path inside the flowers folder, such as flowers/rose.jpg.');
      if (!isNum($price) || !($price >= 0 && $price <= 1e5)) fail(400, 'Enter a valid price.');
      $name = trim($nameInput);
      $lock = row("SELECT GET_LOCK('petalhub_add_product', 30) AS l");
      if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not create the flower right now. Please try again.');
      try {
        // flower names are UNIQUE: a name already on sale is refused, a deleted flower with the same name is put back on sale
        $same = row('SELECT id, active FROM products WHERE name = ?', array($name));
        if ($same && (int)$same['active'] === 1) fail(409, 'A flower with this name already exists.');
        if ($same){
          $id = (int)$same['id'];
          q('UPDATE products SET active = 1, available = 1, qty = 0, price = ?, image_path = ? WHERE id = ?', array($price, $imageInput, $id));
        } else {
          $id = (int)row('SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM products')['next_id'];
          q('INSERT INTO products (id, name, price, qty, unit, description, image_path, active, available) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 1)',
            array($id, $name, $price, 'bunches available', '', $imageInput));
        }
        $created = pub(row('SELECT ' . PCOLS . ' FROM products WHERE id = ?', array($id)));
      } finally {
        q("SELECT RELEASE_LOCK('petalhub_add_product')");
      }
      send(201, $created);
    }
    if ($m === 'DELETE' && preg_match('#^/admin/products/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      inTx(function() use ($id){
        if (!row('SELECT id FROM products WHERE id = ? AND active = 1 FOR UPDATE', array($id))) fail(404, 'Product not found.');
        q('UPDATE products SET active = 0 WHERE id = ?', array($id));
        q('DELETE FROM event_products WHERE product_id = ?', array($id));
        q('DELETE FROM weather_products WHERE product_id = ?', array($id));
      });
      send(200, array('id' => $id, 'deleted' => true));
    }
    if ($m === 'GET' && $route === '/admin/customers') send(200, rows("SELECT " . nameSql('users') . " AS name, email FROM users WHERE role = 'customer' ORDER BY id"));
    if ($m === 'PUT' && $route === '/admin/weather'){
      $weather = get(body(), 'weather');
      if (!is_string($weather) || !in_array($weather, array('', 'sunny', 'rainy'), true)) fail(400, 'Choose Sunny, Rainy, or no weather picks.');
      q("UPDATE petalhub_settings SET setting_value = ? WHERE setting_key = 'weather'", array($weather));
      send(200, array('weather' => $weather));
    }
    if ($m === 'PUT' && preg_match('#^/admin/weather-flowers/(sunny|rainy)$#', $route, $r)){
      $flowerIds = get(body(), 'flowerIds');
      if (!is_array($flowerIds) || count($flowerIds) > 10) fail(400, 'Choose up to 10 flowers for this weather pick.');
      $ids = array();
      foreach ($flowerIds as $id){
        if (!is_int($id) || $id < 1 || isset($ids[$id])) fail(400, 'Invalid flower selection.');
        $ids[$id] = $id;
      }
      if (count($ids)){
        $valid = rows('SELECT id FROM products WHERE active = 1 AND id IN (' . marks(count($ids)) . ')', array_values($ids));
        if (count($valid) !== count($ids)) fail(400, 'One or more selected flowers are no longer available.');
      }
      setPicks('weather_products', 'weather_id', $r[1], array_values($ids));
      send(200, array('weather' => $r[1], 'flowerIds' => array_values($ids)));
    }
    if ($m === 'PUT' && preg_match('#^/admin/events/(valentines|christmas|newyear|mothersday|halloween)$#', $route, $r)){
      $flowerIds = get(body(), 'flowerIds');
      if (!is_array($flowerIds) || count($flowerIds) > 10) fail(400, 'Choose up to 10 flowers for this event.');
      $ids = array();
      foreach ($flowerIds as $id){
        if (!is_int($id) || $id < 1 || isset($ids[$id])) fail(400, 'Invalid flower selection.');
        $ids[$id] = $id;
      }
      if (count($ids)){
        $valid = rows('SELECT id FROM products WHERE active = 1 AND id IN (' . marks(count($ids)) . ')', array_values($ids));
        if (count($valid) !== count($ids)) fail(400, 'One or more selected flowers are no longer available.');
      }
      setPicks('event_products', 'event_id', $r[1], array_values($ids));
      send(200, array('eventId' => $r[1], 'flowerIds' => array_values($ids)));
    }
    if ($m === 'PATCH' && preg_match('#^/admin/orders/(PH-\d+)$#', $route, $r)){
      $s = get(body(), 'status'); $code = $r[1];
      $out = inTx(function() use ($s, $code, $FLOW){
        $o = row('SELECT status, fulfillment, rider_id, payment_status FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$o) fail(404, 'Order not found.');
        $i = array_search($o['status'], $FLOW, true);
        if ($o['payment_status'] === 'awaiting' && $s !== 'Cancelled') fail(400, 'Verify the GCash payment first. The order cannot move forward until the payment is confirmed.');
        if ($s === 'Ready' && $o['fulfillment'] === 'delivery' && $o['rider_id'] === null)
          fail(400, 'Assign a delivery rider before marking this order Ready.');
        if ($s === 'Cancelled' && $i !== false && $i < count($FLOW) - 1){
          returnStock($code);
          if ($o['payment_status'] === 'awaiting') q("UPDATE orders SET payment_status = 'rejected', payment_note = 'Order cancelled before the payment was verified.' WHERE code = ?", array($code));
        } elseif (!($i !== false && isset($FLOW[$i + 1]) && $s === $FLOW[$i + 1])) fail(400, "That status change isn't allowed.");
        q('UPDATE orders SET status = ? WHERE code = ?', array($s, $code));
        return array('code' => $code, 'status' => $s);
      });
      send(200, $out);
    }
    if (preg_match('#^/admin/products/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      if ($m === 'PUT'){
        $b = body(); $price = get($b, 'price'); $qty = get($b, 'qty'); $av = get($b, 'available');
        if (!isNum($price) || !($price >= 0 && $price <= 1e5) || !isInt($qty) || $qty < 0 || $qty > 1e5) fail(400, 'Enter a valid price and quantity.');
        if (!is_bool($av)) fail(400, 'Choose In stock or Out of stock.');
        if (!row('SELECT id FROM products WHERE id = ?', array($id))) fail(404, 'Product not found.');
        $newAvailable = (int)$qty > 0 && $av;
        q('UPDATE products SET price = ?, qty = ?, available = ? WHERE id = ?', array($price, (int)$qty, $newAvailable ? 1 : 0, $id));
        send(200, pub(row('SELECT ' . PCOLS . ' FROM products WHERE id = ?', array($id))));
      }
    }
  }
  fail(404, 'Not found.');
}

try { handle(); }
catch (ApiError $e) { send($e->getCode() ?: 500, array('error' => $e->getMessage())); }
catch (Throwable $e) {
  error_log('PetalHub: ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')');
  // PH_DEBUG (config.php) shows the real reason on screen, which makes problems easy to report. Set it to false when you are done.
  $detail = (!defined('PH_DEBUG') || PH_DEBUG) ? ' ' . $e->getMessage() . ' [' . basename($e->getFile()) . ':' . $e->getLine() . ']' : '';
  send(500, array('error' => 'Server error.' . $detail));
}
