<?php
// Keep this file server-side only. Enter credentials from Brevo's SMTP settings.
define('BREVO_SMTP_HOST', 'smtp-relay.brevo.com');
define('BREVO_SMTP_PORT', 587);
define('BREVO_SMTP_USERNAME', 'c2855e001@smtp-brevo.com');
define('BREVO_SMTP_PASSWORD', 'xsmtpsib-70ae1211cc790584a08e34a0897bba121af3d73a5ea658ee7ddebbd9f93e9060-aC5RpalJkbayrGtz');
define('BREVO_FROM_NAME', 'PetalHub');
define('BREVO_FROM_EMAIL', 'aldrinmae142@gmail.com');
