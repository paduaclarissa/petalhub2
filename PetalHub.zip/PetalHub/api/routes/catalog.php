<?php
if (!defined('PETALHUB_API_ENTRY')) { http_response_code(404); exit; }

/* Public product and shop-information routes. */
  if ($m === 'GET' && $route === '/products')
    send(200, array_map('pub', rows('SELECT id, name, price, qty, unit, description, available, image_path FROM products WHERE active = 1 ORDER BY id')));
  if ($m === 'GET' && $route === '/merchandising') send(200, merchandisingData());
  if ($m === 'GET' && $route === '/payment-info') send(200, paymentSettings());
