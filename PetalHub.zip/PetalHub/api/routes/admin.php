<?php
if (!defined('PETALHUB_API_ENTRY')) { http_response_code(404); exit; }

/* Admin dashboard and shop-management routes. */
  if (strpos($route, '/admin/') === 0){
    if (!$me || $me['role'] !== 'admin') fail(403, 'Admin access only.');
    if ($m === 'GET' && $route === '/admin/dashboard'){
      $orderCursor = (int)row('SELECT UNIX_TIMESTAMP(NOW()) AS order_cursor')['order_cursor'] - 2;
      $orders = toOrders(rows("SELECT o.*, CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC, o.code DESC"));
      send(200, array(
        'orders' => $orders,
        'users' => rows("SELECT fname, mname, lname, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, email FROM users WHERE role = 'customer' ORDER BY id"),
        'products' => array_map('pub', rows('SELECT id, name, price, qty, unit, description, available, image_path FROM products WHERE active = 1 ORDER BY id')),
        'merchandising' => merchandisingData(),
        'riders' => rows("SELECT id, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, phone FROM delivery_riders WHERE active = 1 ORDER BY fname, mname, lname, id"),
        'payInfo' => paymentSettings(),
        'orderCursor' => $orderCursor
      ));
    }
    if ($m === 'GET' && $route === '/admin/orders')
      send(200, toOrders(rows("SELECT o.*, CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC, o.code DESC")));
    if ($m === 'GET' && preg_match('#^/admin/order-updates/(\d+)$#', $route, $r)){
      $since = (int)$r[1];
      if ($since < 1) fail(400, 'Invalid order update cursor.');
      $updates = rows("SELECT o.code, CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS customer, o.status, o.payment_status,
          stats.pending_count, UNIX_TIMESTAMP(NOW()) AS server_time
        FROM (SELECT COUNT(*) AS pending_count FROM orders
          WHERE status = 'Pending' OR (payment_status = 'awaiting' AND status <> 'Cancelled')) stats
        LEFT JOIN orders o ON o.created_at >= FROM_UNIXTIME(?)
        LEFT JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC, o.code DESC", array($since));
      $orders = array();
      foreach ($updates as $update) if ($update['code'] !== null) $orders[] = array(
        'code' => $update['code'], 'customer' => $update['customer'], 'status' => $update['status'],
        'paymentStatus' => $update['payment_status']);
      send(200, array(
        'orders' => $orders,
        'pendingCount' => (int)$updates[0]['pending_count'],
        'cursor' => (int)$updates[0]['server_time']
      ));
    }
    if ($m === 'PUT' && preg_match('#^/admin/orders/(PH-\d+)/payment$#', $route, $r)){
      $code = $r[1]; $b = body(); $action = get($b, 'action'); $note = str(get($b, 'note'), 200);
      if (!in_array($action, array('verify', 'reject'), true)) fail(400, 'Choose Verify or Reject.');
      $out = inTx(function() use ($code, $action, $note){
        $o = row('SELECT status, payment_status FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$o) fail(404, 'Order not found.');
        if ($o['payment_status'] !== 'awaiting') fail(409, 'This payment has already been ' . ($o['payment_status'] === 'verified' ? 'verified.' : ($o['payment_status'] === 'rejected' ? 'rejected.' : 'handled (no GCash payment is waiting).')));
        if ($action === 'verify'){
          q("UPDATE orders SET payment_status = 'verified', paid_at = NOW(), payment_note = ? WHERE code = ?", array($note, $code));
          return array('code' => $code, 'paymentStatus' => 'verified');
        }
        if ($o['status'] === 'Cancelled') fail(409, 'This order is already cancelled.');
        returnStock($code);
        q("UPDATE orders SET payment_status = 'rejected', status = 'Cancelled', payment_note = ? WHERE code = ?", array($note !== '' ? $note : 'The GCash payment could not be verified.', $code));
        return array('code' => $code, 'paymentStatus' => 'rejected', 'status' => 'Cancelled');
      });
      send(200, $out);
    }
    if ($m === 'GET' && preg_match('#^/admin/orders/(PH-\d+)/proof$#', $route, $r)){
      $o = row('SELECT payment_proof FROM orders WHERE code = ?', array($r[1]));
      $file = $o && $o['payment_proof'] !== '' ? paymentDir('proofs') . '/' . basename($o['payment_proof']) : '';
      if ($file === '' || !is_file($file)) fail(404, 'No proof of payment was uploaded for this order.');
      $info = @getimagesize($file);
      header('Content-Type: ' . ($info && !empty($info['mime']) ? $info['mime'] : 'application/octet-stream'));
      header('Content-Length: ' . filesize($file));
      readfile($file); exit;
    }
    if ($m === 'PUT' && $route === '/admin/payment-settings'){
      $b = body(); $name = str(get($b, 'name'), 100); $number = str(get($b, 'number'), 30);
      if ($name === '') fail(400, 'Enter the name shown on the GCash account.');
      if ($number !== '' && !preg_match('/^[0-9+\s-]{7,30}$/', $number)) fail(400, 'Enter a valid GCash mobile number, for example 0917 123 4567.');
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_name', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($name));
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_number', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($number));
      send(200, paymentSettings());
    }
    if ($m === 'POST' && $route === '/admin/payment-qr'){
      $img = decodeImage(get(body(2800000), 'image'), 2000000);
      protectPaymentDirs();
      $dir = paymentDir();
      foreach (glob($dir . '/gcash-qr-custom.*') ?: array() as $old) @unlink($old);
      $path = 'payments/gcash-qr-custom.' . $img['ext'];
      if (@file_put_contents(PETALHUB_ROOT . '/' . $path, $img['bin']) === false) fail(500, 'The QR image could not be saved. Check that the petalhub/payments folder can be written to.');
      q("INSERT INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_qr', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)", array($path));
      send(200, paymentSettings());
    }
    if ($m === 'GET' && $route === '/admin/riders')
      send(200, rows("SELECT id, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, phone FROM delivery_riders WHERE active = 1 ORDER BY fname, mname, lname, id"));
    if ($m === 'POST' && $route === '/admin/riders'){
      $b = body(); $name = personNameParts($b); $display = displayName($name); $phone = str(get($b, 'phone'), 30);
      if ($name['fname'] === '' || $name['lname'] === '') fail(400, 'Enter the rider’s first and last name.');
      if (!preg_match('/^09[0-9]{9}$/', $phone)) fail(400, 'Enter an 11-digit Philippine mobile number starting with 09.');
      $normalizedPhone = $phone;
      $lock = row("SELECT GET_LOCK('petalhub_add_rider', 30) AS l");
      if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not save the rider right now. Please try again.');
      try {
        foreach (rows('SELECT phone FROM delivery_riders WHERE active = 1') as $existingRider){
          if (preg_replace('/\\D/', '', $existingRider['phone']) === $normalizedPhone)
            fail(409, 'A rider with this phone number already exists.');
        }
        if (hasColumn('delivery_riders', 'name')){
          q('INSERT INTO delivery_riders (name, fname, mname, lname, phone) VALUES (?, ?, ?, ?, ?)',
            array($display, $name['fname'], $name['mname'], $name['lname'], $phone));
        } else {
          q('INSERT INTO delivery_riders (fname, mname, lname, phone) VALUES (?, ?, ?, ?)', array($name['fname'], $name['mname'], $name['lname'], $phone));
        }
        $created = array('id' => (int)db()->lastInsertId(), 'name' => $display, 'phone' => $phone);
      } finally {
        q("SELECT RELEASE_LOCK('petalhub_add_rider')");
      }
      send(201, $created);
    }
    if ($m === 'DELETE' && preg_match('#^/admin/riders/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      inTx(function() use ($id){
        $deleted = q('DELETE FROM delivery_riders WHERE id = ?', array($id));
        if ($deleted->rowCount() !== 1) fail(404, 'Delivery rider not found.');
        q('UPDATE orders SET rider_id = NULL WHERE rider_id = ?', array($id));
      });
      send(200, array('id' => $id, 'deleted' => true));
    }
    if ($m === 'PUT' && preg_match('#^/admin/orders/(PH-\d+)/rider$#', $route, $r)){
      $code = $r[1]; $riderId = get(body(), 'riderId');
      if ($riderId !== null && (!is_int($riderId) || $riderId < 1)) fail(400, 'Choose a valid delivery rider.');
      $result = inTx(function() use ($code, $riderId){
        $order = row('SELECT fulfillment FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$order) fail(404, 'Order not found.');
        if ($order['fulfillment'] !== 'delivery') fail(400, 'A delivery rider can only be assigned to delivery orders.');
        if ($riderId === null){
          q("UPDATE orders SET rider_id = NULL, rider_name = '', rider_phone = '' WHERE code = ?", array($code));
          return array('riderId' => null, 'riderName' => '', 'riderPhone' => '');
        }
        $rider = row("SELECT id, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, phone FROM delivery_riders WHERE id = ? AND active = 1", array($riderId));
        if (!$rider) fail(404, 'Delivery rider not found.');
        q('UPDATE orders SET rider_id = ?, rider_name = ?, rider_phone = ? WHERE code = ?', array($rider['id'], $rider['name'], $rider['phone'], $code));
        return array('riderId' => (int)$rider['id'], 'riderName' => $rider['name'], 'riderPhone' => $rider['phone']);
      });
      send(200, array_merge(array('code' => $code), $result));
    }
    if ($m === 'GET' && $route === '/admin/products') send(200, array_map('pub', rows('SELECT id, name, price, qty, unit, description, available, image_path FROM products WHERE active = 1 ORDER BY id')));
    if ($m === 'POST' && $route === '/admin/products'){
      $b = body(); $nameInput = get($b, 'name'); $imageInput = get($b, 'imagePath'); $descriptionInput = get($b, 'description', ''); $price = get($b, 'price');
      if (!is_string($nameInput) || trim($nameInput) === '' || strlen(trim($nameInput)) > 80) fail(400, 'Enter a flower name up to 80 characters.');
      if (!is_string($imageInput) || !preg_match('#^flowers/[A-Za-z0-9 _.()-]+\.(jpg|jpeg|png|webp|gif)$#i', trim($imageInput))) fail(400, 'Enter an image path inside the flowers folder, such as flowers/White roses.jpg.');
      if (!is_string($descriptionInput) || strlen(trim($descriptionInput)) > 300) fail(400, 'Flower descriptions must be 300 characters or fewer.');
      if (!isNum($price) || !($price >= 0 && $price <= 1e5)) fail(400, 'Enter a valid price.');
      $name = trim($nameInput); $description = trim($descriptionInput);
      $created = null;
      for ($attempt = 0; $attempt < 3; $attempt++){
        try {
          $created = inTx(function() use ($name, $description, $price, $imageInput){
            $lastProduct = row('SELECT id FROM products ORDER BY id DESC LIMIT 1 FOR UPDATE');
            $id = $lastProduct ? (int)$lastProduct['id'] + 1 : 1;
            q('INSERT INTO products (id, name, price, qty, unit, description, image_path, active, available) VALUES (?, ?, ?, 0, ?, ?, ?, 1, 1)',
              array($id, $name, $price, 'bunches available', $description, trim($imageInput)));
            return pub(row('SELECT id, name, price, qty, unit, description, available, image_path FROM products WHERE id = ?', array($id)));
          });
          break;
        } catch (PDOException $e){
          $driverCode = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
          if (!in_array($driverCode, array(1062, 1213), true) || $attempt === 2) throw $e;
        }
      }
      send(201, $created);
    }
    if ($m === 'DELETE' && preg_match('#^/admin/products/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      inTx(function() use ($id){
        $deleted = q('DELETE FROM products WHERE id = ? AND active = 1', array($id));
        if ($deleted->rowCount() !== 1) fail(404, 'Product not found.');
      });
      send(200, array('id' => $id, 'deleted' => true));
    }
    if ($m === 'GET' && $route === '/admin/customers') send(200, rows("SELECT fname, mname, lname, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, email FROM users WHERE role = 'customer' ORDER BY id"));
    if ($m === 'PUT' && $route === '/admin/weather'){
      $weather = get(body(), 'weather');
      if (!is_string($weather) || !in_array($weather, array('', 'sunny', 'rainy'), true)) fail(400, 'Choose Sunny, Rainy, or no weather picks.');
      q("UPDATE petalhub_settings SET setting_value = ? WHERE setting_key = 'weather'", array($weather));
      send(200, array('weather' => $weather));
    }
    if ($m === 'PUT' && preg_match('#^/admin/weather-flowers/(sunny|rainy)$#', $route, $r)){
      $flowerIds = get(body(), 'flowerIds');
      if (!is_array($flowerIds) || count($flowerIds) > 10) fail(400, 'Choose up to 10 flowers for this weather pick.');
      $ids = array();
      foreach ($flowerIds as $id){
        if (!is_int($id) || $id < 1 || isset($ids[$id])) fail(400, 'Invalid flower selection.');
        $ids[$id] = $id;
      }
      if (count($ids)){
        $valid = rows('SELECT id FROM products WHERE active = 1 AND id IN (' . marks(count($ids)) . ')', array_values($ids));
        if (count($valid) !== count($ids)) fail(400, 'One or more selected flowers are no longer available.');
      }
      inTx(function() use ($ids, $r){
        q('DELETE FROM weather_products WHERE weather_id = ?', array($r[1]));
        foreach ($ids as $id) q('INSERT INTO weather_products (weather_id, product_id) VALUES (?, ?)', array($r[1], $id));
      });
      send(200, array('weather' => $r[1], 'flowerIds' => array_values($ids)));
    }
    if ($m === 'PUT' && preg_match('#^/admin/events/(valentines|christmas|newyear|mothersday|halloween)$#', $route, $r)){
      $flowerIds = get(body(), 'flowerIds');
      if (!is_array($flowerIds) || count($flowerIds) > 10) fail(400, 'Choose up to 10 flowers for this event.');
      $ids = array();
      foreach ($flowerIds as $id){
        if (!is_int($id) || $id < 1 || isset($ids[$id])) fail(400, 'Invalid flower selection.');
        $ids[$id] = $id;
      }
      if (count($ids)){
        $valid = rows('SELECT id FROM products WHERE active = 1 AND id IN (' . marks(count($ids)) . ')', array_values($ids));
        if (count($valid) !== count($ids)) fail(400, 'One or more selected flowers are no longer available.');
      }
      inTx(function() use ($ids, $r){
        q('DELETE FROM event_products WHERE event_id = ?', array($r[1]));
        foreach ($ids as $id) q('INSERT INTO event_products (event_id, product_id) VALUES (?, ?)', array($r[1], $id));
      });
      send(200, array('eventId' => $r[1], 'flowerIds' => array_values($ids)));
    }
    if ($m === 'PATCH' && preg_match('#^/admin/orders/(PH-\d+)$#', $route, $r)){
      $s = get(body(), 'status'); $code = $r[1];
      $out = inTx(function() use ($s, $code, $FLOW){
        $o = row('SELECT status, fulfillment, rider_id, payment_status FROM orders WHERE code = ? FOR UPDATE', array($code));
        if (!$o) fail(404, 'Order not found.');
        $i = array_search($o['status'], $FLOW, true);
        if ($o['payment_status'] === 'awaiting' && $s !== 'Cancelled') fail(400, 'Verify the GCash payment first. The order cannot move forward until the payment is confirmed.');
        if ($s === 'Ready' && $o['fulfillment'] === 'delivery' && $o['rider_id'] === null)
          fail(400, 'Assign a delivery rider before marking this order Ready.');
        if ($s === 'Cancelled' && $i !== false && $i < count($FLOW) - 1){
          returnStock($code);
          if ($o['payment_status'] === 'awaiting') q("UPDATE orders SET payment_status = 'rejected', payment_note = 'Order cancelled before the payment was verified.' WHERE code = ?", array($code));
        } elseif (!($i !== false && isset($FLOW[$i + 1]) && $s === $FLOW[$i + 1])) fail(400, "That status change isn't allowed.");
        if ($s === 'Completed' && $o['fulfillment'] === 'pickup')
          q('UPDATE orders SET status = ?, paid_at = COALESCE(paid_at, NOW()) WHERE code = ?', array($s, $code));
        else q('UPDATE orders SET status = ? WHERE code = ?', array($s, $code));
        return array('code' => $code, 'status' => $s);
      });
      send(200, $out);
    }
    if (preg_match('#^/admin/products/(\d+)$#', $route, $r)){
      $id = (int)$r[1];
      if ($m === 'PUT'){
        $b = body(); $name = get($b, 'name'); $description = get($b, 'description'); $imagePath = get($b, 'imagePath');
        $price = get($b, 'price'); $qty = get($b, 'qty'); $av = get($b, 'available');
        if (!is_string($name) || trim($name) === '' || strlen(trim($name)) > 80) fail(400, 'Enter a flower name up to 80 characters.');
        if (!is_string($description) || strlen(trim($description)) > 300) fail(400, 'Flower descriptions must be 300 characters or fewer.');
        if (!is_string($imagePath) || !preg_match('#^flowers/[A-Za-z0-9 _.()-]+\.(jpg|jpeg|png|webp|gif)$#i', trim($imagePath))) fail(400, 'Choose an image path inside the flowers folder.');
        if (!isNum($price) || !($price >= 0 && $price <= 1e5) || !isInt($qty) || $qty < 0 || $qty > 1e5) fail(400, 'Enter a valid price and quantity.');
        if (!is_bool($av)) fail(400, 'Choose In stock or Out of stock.');
        if (!row('SELECT id FROM products WHERE id = ?', array($id))) fail(404, 'Product not found.');
        $newAvailable = (int)$qty > 0 && $av;
        q('UPDATE products SET name = ?, description = ?, image_path = ?, price = ?, qty = ?, available = ? WHERE id = ?',
          array(trim($name), trim($description), trim($imagePath), $price, (int)$qty, $newAvailable ? 1 : 0, $id));
        send(200, pub(row('SELECT id, name, price, qty, unit, description, available, image_path FROM products WHERE id = ?', array($id))));
      }
    }
  }
