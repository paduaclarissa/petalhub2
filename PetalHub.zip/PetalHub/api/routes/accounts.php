<?php
if (!defined('PETALHUB_API_ENTRY')) { http_response_code(404); exit; }

/* Registration, login, account details, and password recovery routes. */
  if ($m === 'GET' && $route === '/password-reset/csrf'){
    startResetSession();
    if (!isset($_SESSION['reset_csrf'])) $_SESSION['reset_csrf'] = bin2hex(random_bytes(32));
    send(200, array('csrfToken' => $_SESSION['reset_csrf']));
  }
  if ($m === 'POST' && $route === '/password-reset/request'){
    checkResetCsrf();
    if (throttled('password-reset-request')) fail(429, 'Too many requests. Please wait a few minutes and try again.');
    if (!passwordResetMailConfigured())
      fail(503, 'Password reset is temporarily unavailable. Please contact the shop.');
    $email = lower(str(get(body(), 'email'), 200));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail(400, 'Enter a valid email address.');
    $user = row("SELECT id FROM users WHERE email = ? AND role = 'customer'", array($email));
    if ($user){
      $previous = row('SELECT UNIX_TIMESTAMP(requested_at) AS requested_at FROM password_reset_codes WHERE user_id = ?', array($user['id']));
      if (!$previous || time() - (int)$previous['requested_at'] >= 60){
        $code = (string)random_int(100000, 999999);
        $codeHash = password_hash($code, PASSWORD_DEFAULT);
        q('INSERT INTO password_reset_codes (user_id, code_hash, expires_at, attempts, requested_at, reset_token_hash, reset_expires_at)
          VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), 0, NOW(), NULL, NULL)
          ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), attempts = 0, requested_at = NOW(), reset_token_hash = NULL, reset_expires_at = NULL',
          array($user['id'], $codeHash));
        if (!sendPasswordResetEmail($email, $code))
          q('DELETE FROM password_reset_codes WHERE user_id = ? AND code_hash = ?', array($user['id'], $codeHash));
      }
    }
    send(200, array('message' => 'If an account exists for that email, a code has been sent. Check your inbox and spam folder.', 'resendAfter' => 60));
  }
  if ($m === 'POST' && $route === '/password-reset/verify'){
    checkResetCsrf();
    if (throttled('password-reset-verify')) fail(429, 'Too many attempts. Please wait a few minutes and try again.');
    $b = body();
    $email = lower(str(get($b, 'email'), 200));
    $code = is_string(get($b, 'code')) ? trim($b['code']) : '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{6}$/', $code)) fail(400, 'Enter a valid email address and six-digit code.');
    $resetToken = bin2hex(random_bytes(32));
    $verified = inTx(function() use ($email, $code, $resetToken){
      $record = row("SELECT p.user_id, p.code_hash, p.expires_at, p.attempts, p.reset_token_hash
        FROM password_reset_codes p JOIN users u ON u.id = p.user_id
        WHERE u.email = ? AND u.role = 'customer' FOR UPDATE", array($email));
      if (!$record || $record['reset_token_hash'] !== null || strtotime($record['expires_at']) <= time()) return false;
      if ((int)$record['attempts'] >= 3){
        q('DELETE FROM password_reset_codes WHERE user_id = ?', array($record['user_id']));
        return false;
      }
      if (!password_verify($code, $record['code_hash'])){
        if ((int)$record['attempts'] >= 2) q('DELETE FROM password_reset_codes WHERE user_id = ?', array($record['user_id']));
        else q('UPDATE password_reset_codes SET attempts = attempts + 1 WHERE user_id = ?', array($record['user_id']));
        return false;
      }
      q("UPDATE password_reset_codes SET code_hash = '', reset_token_hash = ?, reset_expires_at = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
        WHERE user_id = ?", array(hash('sha256', $resetToken), $record['user_id']));
      return true;
    });
    if (!$verified) fail(400, 'That code is incorrect or expired. Check it and try again; after 3 wrong tries, request a new code.');
    if (!session_regenerate_id(true)) fail(500, 'Could not secure the password reset session. Please request a new code.');
    send(200, array('resetToken' => $resetToken));
  }
  if ($m === 'POST' && $route === '/password-reset/complete'){
    checkResetCsrf();
    if (throttled('password-reset-complete')) fail(429, 'Too many attempts. Please wait a few minutes and try again.');
    $b = body();
    $resetToken = is_string(get($b, 'resetToken')) ? trim($b['resetToken']) : '';
    $password = is_string(get($b, 'password')) ? $b['password'] : '';
    if (!preg_match('/^[a-f0-9]{64}$/', $resetToken)) fail(400, 'Your reset session is invalid. Request a new code.');
    if (strlen($password) < 8 || strlen($password) > 72) fail(400, 'Choose a password between 8 and 72 characters.');
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    if ($passwordHash === false) fail(500, 'Could not save your new password. Please try again.');
    $updated = inTx(function() use ($resetToken, $passwordHash){
      $record = row('SELECT user_id FROM password_reset_codes WHERE reset_token_hash = ? AND reset_expires_at > NOW() FOR UPDATE',
        array(hash('sha256', $resetToken)));
      if (!$record) return false;
      q('UPDATE users SET password_hash = ?, salt = ? WHERE id = ? AND role = ?',
        array($passwordHash, newSalt(), $record['user_id'], 'customer'));
      q('DELETE FROM sessions WHERE user_id = ?', array($record['user_id']));
      q('DELETE FROM password_reset_codes WHERE user_id = ?', array($record['user_id']));
      return true;
    });
    if (!$updated) fail(400, 'Your reset session is invalid or expired. Request a new code.');
    $_SESSION = array();
    session_destroy();
    send(200, array('message' => 'Your password has been updated. Please log in with your new password.'));
  }
  if ($m === 'POST' && $route === '/logout'){ if (bearer() !== '') q('DELETE FROM sessions WHERE token_hash = ?', array(hash('sha256', bearer()))); send(200, emptyObj()); }
  $me = in_array($route, array('/login', '/register', '/logout'), true) ? null : authUser();
  if ($m === 'GET' && $route === '/me') $me ? send(200, array('user' => array('name' => $me['name'], 'email' => $me['email'], 'role' => $me['role']))) : send(401, array('error' => 'Please log in.'));

  if ($m === 'GET' && $route === '/addresses'){
    if (!$me) fail(401, 'Please log in.');
    send(200, array_map(function($address){
      $address['id'] = (int)$address['id'];
      return $address;
    }, rows('SELECT id, street, city, zip, contact_phone AS phone FROM addresses WHERE user_id = ? ORDER BY created_at DESC, id DESC', array($me['id']))));
  }
  if ($m === 'POST' && $route === '/addresses'){
    if (!$me) fail(401, 'Please log in.');
    $b = body();
    $street = str(get($b, 'street'), 200);
    $city = str(get($b, 'city'), 100);
    $zip = str(get($b, 'zip'), 20);
    $phone = str(get($b, 'phone'), 30);
    if ($street === '' || $city === '') fail(400, 'Enter a street address and city or town.');
    if (!preg_match('/^09[0-9]{9}$/', $phone)) fail(400, 'Enter an 11-digit Philippine mobile number starting with 09.');
    $existing = row('SELECT id FROM addresses WHERE user_id = ? AND street = ? AND city = ? AND zip = ? AND contact_phone = ? ORDER BY id LIMIT 1',
      array($me['id'], $street, $city, $zip, $phone));
    if ($existing) $id = (int)$existing['id'];
    else {
      q('INSERT INTO addresses (user_id, street, city, zip, contact_phone) VALUES (?, ?, ?, ?, ?)',
        array($me['id'], $street, $city, $zip, $phone));
      $id = (int)db()->lastInsertId();
    }
    send($existing ? 200 : 201, array('id' => $id, 'street' => $street, 'city' => $city, 'zip' => $zip, 'phone' => $phone));
  }
  if (preg_match('#^/addresses/(\d+)$#', $route, $addressMatch)){
    if (!$me) fail(401, 'Please log in.');
    $addressId = (int)$addressMatch[1];
    if ($m === 'PUT'){
      $b = body();
      $street = str(get($b, 'street'), 200);
      $city = str(get($b, 'city'), 100);
      $zip = str(get($b, 'zip'), 20);
      $phone = str(get($b, 'phone'), 30);
      if ($street === '' || $city === '') fail(400, 'Enter a street address and city or town.');
      if (!preg_match('/^09[0-9]{9}$/', $phone)) fail(400, 'Enter an 11-digit Philippine mobile number starting with 09.');
      if (!row('SELECT id FROM addresses WHERE id = ? AND user_id = ?', array($addressId, $me['id']))) fail(404, 'Saved address not found.');
      q('UPDATE addresses SET street = ?, city = ?, zip = ?, contact_phone = ? WHERE id = ? AND user_id = ?',
        array($street, $city, $zip, $phone, $addressId, $me['id']));
      send(200, array('id' => $addressId, 'street' => $street, 'city' => $city, 'zip' => $zip, 'phone' => $phone));
    }
    if ($m === 'DELETE'){
      $deleted = q('DELETE FROM addresses WHERE id = ? AND user_id = ?', array($addressId, $me['id']))->rowCount();
      if (!$deleted) fail(404, 'Saved address not found.');
      send(200, array('id' => $addressId));
    }
  }

  if ($m === 'POST' && ($route === '/register' || $route === '/login')){
    if (throttled()) fail(429, 'Too many attempts. Try again in a few minutes.');
    $b = body(); $email = lower(str(get($b, 'email'), 200)); $pw = is_string(get($b, 'pass')) ? $b['pass'] : '';
    if ($route === '/login'){
      $u = row("SELECT id, CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) AS name, email, salt, password_hash, role FROM users WHERE email = ?", array($email));
      if (!$u || !checkHash($u['password_hash'], $pw, $u['salt'])) fail(401, 'Incorrect email or password.');
      if (substr($u['password_hash'], 0, 3) !== 'p2:' && (!isset($u['password_hash'][0]) || $u['password_hash'][0] !== '$')){ $s = newSalt(); q('UPDATE users SET salt = ?, password_hash = ? WHERE id = ?', array($s, hashPw($pw, $s), $u['id'])); }
      startSession($u);
    }
    $name = personNameParts($b);
    if ($name['fname'] === '' || $name['lname'] === '' || !preg_match('/^\S+@\S+\.\S+$/', $email)) fail(400, 'Enter your first name, last name, and a valid email.');
    if (strlen($pw) < 6) fail(400, 'Password must be at least 6 characters.');
    try { $id = addUser($name, $email, $pw, 'customer'); }
    catch (PDOException $e){
      if (isset($e->errorInfo[1]) && (int)$e->errorInfo[1] === 1062) fail(409, 'An account with that email already exists. Please log in.');
      throw $e;
    }
    startSession(array('id' => $id, 'name' => displayName($name), 'email' => $email, 'role' => 'customer'));
  }
