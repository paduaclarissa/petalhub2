(function(){
  "use strict";

  window.PetalHubAdmin = function(context){
    var state = context.state;
    var db = context.db;
    var STATUS_FLOW = context.STATUS_FLOW;
    var CURRENCY = context.CURRENCY;
    var WEATHER_PRESETS = context.WEATHER_PRESETS;
    var OCCASIONS = context.OCCASIONS;
    var api = context.api;
    var render = context.render;
    var notify = context.notify;
    var loadAdmin = context.loadAdmin;
    var loadProducts = context.loadProducts;
    var showErr = context.showErr;
    var showWarning = context.showWarning;
    var showConfirm = context.showConfirm;
    var shrinkImage = context.shrinkImage;
    var flowerById = context.flowerById;
    var stockQty = context.stockQty;
    var esc = context.esc;
    var money = context.money;
    var payBadge = context.payBadge;
    var orderLinesHtml = context.orderLinesHtml;
    var orderCategory = context.orderCategory;
    var dupOf = context.dupOf;
    var iconQr = context.iconQr;
    var flowerPhoto = context.flowerPhoto;

  function adminStats(){
    var today = new Date().toDateString();
    var todayCount = db.orders.filter(function(o){ return new Date(o.date).toDateString() === today; }).length;
    var pending = db.orders.filter(function(o){ return o.status === "Pending"; }).length;
    var verify = db.orders.filter(function(o){ return o.paymentStatus === "awaiting" && o.status !== "Cancelled"; }).length;
    var low = db.products.filter(function(p){ return stockQty(p) === 0 || (typeof p.qty === "number" && p.qty <= 5); }).length;
    var cards = [
      ["Orders today", todayCount, "placed since midnight", ""],
      ["Pending orders", pending, "waiting to be prepared", pending ? "warn" : ""],
      ["GCash to verify", verify, verify ? "check your GCash transactions" : "nothing waiting", verify ? "alert" : ""],
      ["Low or out of stock", low, "flowers at 5 or fewer", low ? "warn" : ""]
    ];
    return '<div class="stat-grid">' + cards.map(function(c){
      return '<div class="stat-card ' + c[3] + '"><span class="stat-label">' + c[0] + '</span><strong class="stat-value">' + c[1] + '</strong><span class="stat-hint">' + c[2] + '</span></div>';
    }).join("") + '</div>';
  }
  function adminPayBlock(o){
    if (o.payment !== "GCash (QR)") return "";
    var awaiting = o.paymentStatus === "awaiting" && o.status !== "Cancelled", code = esc(o.code);
    return '<div class="admin-pay ' + esc(o.paymentStatus) + '"><div class="admin-pay-head"><strong>GCash payment</strong>' + payBadge(o) + '</div>' +
      '<div class="admin-pay-grid"><span>Reference no.</span><strong class="mono">' + esc(o.gcashRef || "\u2014") + '</strong>' +
      '<span>Amount to match</span><strong>' + money(o.total) + '</strong>' +
      (o.paidAt ? '<span>Verified on</span><strong>' + esc(new Date(o.paidAt).toLocaleString()) + '</strong>' : '') + '</div>' +
      (o.hasProof ? '<button type="button" class="logout-btn" onclick="App.viewProof(\'' + code + '\')">View receipt screenshot</button>' : '<p class="sub" style="margin:0">No receipt screenshot was uploaded.</p>') +
      (awaiting ? '<p class="sub" style="margin:8px 0 0">Open your GCash transactions and look for this reference number and amount. Then verify or reject the payment.</p>' +
        '<label class="pay-note-field">Note to customer (optional)<input id="pay-note-' + code + '" type="text" maxlength="200" placeholder="e.g. The amount did not match"></label>' +
        '<div class="admin-actions"><button class="btn" onclick="App.verifyPayment(\'' + code + '\')">Verify payment</button><button class="logout-btn product-delete-btn" onclick="App.rejectPayment(\'' + code + '\')">Reject payment</button></div>' : '') +
      (o.paymentNote && o.paymentStatus !== "awaiting" ? '<p class="sub" style="margin:8px 0 0">Note: ' + esc(o.paymentNote) + '</p>' : '') +
      (o.status === "Cancelled" && o.paymentStatus === "verified" ? '<p class="dup-flag">This order was cancelled after its payment was verified. Refund the customer through GCash.</p>' : '') + '</div>';
  }
  function adminOrdersBody(){
    var verifyCount = db.orders.filter(function(o){ return o.paymentStatus === "awaiting" && o.status !== "Cancelled"; }).length;
    var orderFilters = [
      { id: "verify", label: "Verify payment", count: verifyCount },
      { id: "ongoing", label: "Ongoing", count: db.orders.filter(function(o){ return orderCategory(o) === "ongoing"; }).length },
      { id: "completed", label: "Completed", count: db.orders.filter(function(o){ return orderCategory(o) === "completed"; }).length },
      { id: "cancelled", label: "Cancelled", count: db.orders.filter(function(o){ return orderCategory(o) === "cancelled"; }).length }
    ];
    var orderFilterButtons = orderFilters.map(function(filter){
      return '<button class="' + (state.adminOrderFilter === filter.id ? 'btn' : 'logout-btn') + (filter.id === "verify" && filter.count ? ' attention' : '') + '" onclick="App.setAdminOrderFilter(\'' + filter.id + '\')">' + filter.label + ' (' + filter.count + ')</button>';
    }).join("");
    var filteredOrders = db.orders.filter(function(order){
      return state.adminOrderFilter === "verify" ? (order.paymentStatus === "awaiting" && order.status !== "Cancelled") : orderCategory(order) === state.adminOrderFilter;
    });
    var cards = filteredOrders.map(function(o){
      var idx = STATUS_FLOW.indexOf(o.status), next = idx >= 0 ? STATUS_FLOW[idx + 1] : null;
      var awaiting = o.paymentStatus === "awaiting" && o.status !== "Cancelled";
      var readyNeedsRider = next === "Ready" && o.fulfillment === "delivery" && !o.riderId;
      var riderOptions = '<option value="">Not assigned</option>' + db.riders.map(function(rider){
        return '<option value="' + rider.id + '"' + (Number(o.riderId) === Number(rider.id) ? ' selected' : '') + '>' + esc(rider.name) + ' \u00b7 ' + esc(rider.phone) + '</option>';
      }).join("");
      return '<div class="admin-card order-card' + (awaiting ? ' needs-payment' : '') + '"><div class="row"><strong>' + esc(o.code) + '</strong><span class="admin-badges">' + payBadge(o) + '<span class="admin-status">' + esc(o.status) + '</span></span></div>' +
        '<p class="sub">' + esc(new Date(o.date).toLocaleString()) + ' \u2014 ' + esc(o.customer) + ' (' + esc(o.email) + ')</p>' +
        orderLinesHtml(o) + '<div class="order-total"><span>Total</span><strong>' + money(o.total) + '</strong></div>' + adminPayBlock(o) +
        (dupOf(o) ? '<p class="dup-flag">\u26a0 Possible duplicate of ' + esc(dupOf(o)) + ' (same customer, items and total within 30 minutes). Cancel this one if the customer only ordered once \u2014 stock is returned automatically.</p>' : '') +
        (o.fulfillment === "delivery" ?
          '<div class="admin-delivery-address"><strong>Delivery address</strong><span>' + esc([o.address.street, o.address.city, o.address.zip].filter(Boolean).join(", ") || "No address provided") + '</span>' +
          '<strong>Customer phone</strong><span>' + (o.customerPhone ? '<a href="tel:' + esc(o.customerPhone) + '">' + esc(o.customerPhone) + '</a>' : 'No phone provided') + '</span>' +
          '<label class="rider-assignment">Delivery rider<select id="rider-select-' + esc(o.code) + '">' + riderOptions + '</select></label><button class="btn" onclick="App.assignRider(\'' + esc(o.code) + '\')">Save rider assignment</button>' +
          (o.riderName ? '<span class="sub">Assigned: ' + esc(o.riderName) + ' \u00b7 ' + esc(o.riderPhone) + '</span>' : '') + '</div>' :
          '<p class="sub">Pickup at store</p>') +
        (o.payment !== "GCash (QR)" ? '<p class="sub admin-order-payment">Payment: ' + esc(o.payment) + '</p>' : '') +
        (readyNeedsRider ? '<p class="sub">Assign a rider before marking this delivery Ready.</p>' : '') +
        (awaiting ? '<p class="sub">Verify the GCash payment above before this order can move forward.</p>' : '') +
        (next ? '<div class="admin-actions"><button class="btn" ' + (readyNeedsRider || awaiting ? 'disabled title="' + (awaiting ? 'Verify the GCash payment first' : 'Assign a rider first') + '"' : '') + ' onclick="App.setStatus(\'' + o.code + '\',\'' + next + '\')">Mark ' + next + '</button><button class="logout-btn" onclick="App.cancelOrder(\'' + o.code + '\')">Cancel order</button></div>' : '') + '</div>';
    }).join("");
    return '<div class="order-filter-tabs" role="group" aria-label="Filter orders">' + orderFilterButtons + '</div>' +
      (filteredOrders.length ? '<div class="admin-grid">' + cards + '</div>' :
        '<p class="sub">' + (state.adminOrderFilter === "verify" ? 'No GCash payments are waiting for verification.' : (db.orders.length ? 'No ' + state.adminOrderFilter + ' orders.' : 'No orders yet.')) + '</p>');
  }
  function adminPaymentsBody(){
    var info = state.payInfo || { name: "", number: "", qr: "", hasQr: false };
    var sample = /payments\/gcash-qr\.png/.test(info.qr || "");
    return '<div class="admin-grid">' +
      '<div class="admin-card"><h3>GCash QR code</h3><p class="sub">Customers scan this QR code at checkout. Upload the QR code from your own GCash app (GCash \u2192 QR \u2192 save to your photos).</p>' +
        '<div class="qr-admin"><div class="qr-admin-img">' + (state.qrDraft ? '<img src="' + esc(state.qrDraft) + '" alt="Preview of the new QR code">' : (info.hasQr ? '<img src="' + esc(info.qr) + '" alt="Current GCash QR code">' : '<span class="sub">No QR code yet</span>')) + '</div>' +
        '<div class="qr-admin-side"><label class="file-drop small"><input type="file" accept="image/png,image/jpeg,image/webp" onchange="App.pickQr(this)"><span>' + iconQr() + 'Choose a QR image</span></label>' +
          (state.qrDraft ? '<div class="admin-actions"><button class="btn" onclick="App.saveQr()">Use this QR code</button><button class="logout-btn" onclick="App.cancelQr()">Cancel</button></div><p class="sub">This is only a preview. Customers see it after you press Use this QR code.</p>' : '') +
          (sample && !state.qrDraft ? '<p class="dup-flag">You are still using the sample QR code. Upload your real GCash QR code before customers pay.</p>' : '') + '</div></div></div>' +
      '<div class="admin-card"><h3>Account shown to customers</h3><p class="sub">Shown beside the QR code so customers can check they are paying the right account.</p>' +
        '<div class="product-create-form single"><label>Account name<input id="gcash-name" type="text" maxlength="100" value="' + esc(info.name) + '"></label>' +
        '<label>GCash mobile number<input id="gcash-number" type="tel" maxlength="30" placeholder="0917 123 4567" value="' + esc(info.number) + '"></label>' +
        '<button class="btn" onclick="App.saveGcashSettings()">Save account details</button></div></div>' +
      '<div class="admin-card"><h3>How payment verification works</h3><ol class="pay-steps compact"><li>The customer scans your QR code, pays, and submits the 13-digit GCash reference number (and optionally a screenshot).</li>' +
        '<li>The order appears under <strong>Orders \u2192 Verify payment</strong> and cannot move forward yet.</li><li>You check your GCash transactions for that reference number and amount, then press <strong>Verify payment</strong>.</li>' +
        '<li>The customer is notified and the order is confirmed. If the payment is wrong, press <strong>Reject payment</strong>: the order is cancelled and the stock is returned.</li></ol></div></div>';
  }
  function openLightbox(url, caption){
    var old = document.getElementById("lightbox"); if (old) old.remove();
    var box = document.createElement("div");
    box.id = "lightbox"; box.className = "lightbox"; box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-label", caption);
    box.innerHTML = '<figure><img alt="' + esc(caption) + '" src="' + url + '"><figcaption>' + esc(caption) + '</figcaption><button type="button" class="btn secondary" id="lightbox-close">Close</button></figure>';
    function close(){ box.remove(); URL.revokeObjectURL(url); document.removeEventListener("keydown", onKey); }
    function onKey(e){ if (e.key === "Escape") close(); }
    box.addEventListener("click", function(e){ if (e.target === box) close(); });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(box);
    document.getElementById("lightbox-close").addEventListener("click", close);
    document.getElementById("lightbox-close").focus();
  }
  // Re-encode a picked image in the browser (smaller upload, strips camera metadata). Resolves to a data URL.
  function apiBlob(url){
    var headers = {}; if (TOKEN){ headers.Authorization = "Bearer " + TOKEN; headers["X-Auth-Token"] = TOKEN; }
    return fetch(apiUrl(url), { headers: headers }).then(function(r){
      if (r.ok) return r.blob();
      return r.json().catch(function(){ return {}; }).then(function(j){ throw new Error(j.error || "The file could not be opened."); });
    }, function(){ throw new Error(SERVER_DOWN); });
  }

  function screenAdmin(){
    var tab = state.adminTab;
    var help = {
      orders: "Review new orders, verify GCash payments, and move each order forward (Pending \u2192 Preparing \u2192 Ready \u2192 Completed). Cancelling returns the stems to stock.",
      products: "Set the price, quantity and In stock / Out of stock status of each flower. Customers see exactly what you set here.",
      merchandising: "Choose the weather recommendations shown in the shop and manage flowers featured for each event.",
      customers: "See registered customers and how many orders each has placed.",
      riders: "Add delivery riders, or remove riders who should no longer be available for new delivery assignments.",
      payments: "Set up the GCash QR code customers scan at checkout, and see how payment verification works."
    }[tab];
    var attention = db.orders.filter(function(order){ return order.status === "Pending" || (order.paymentStatus === "awaiting" && order.status !== "Cancelled"); }).length;
    var tabs = [["orders", "Orders"], ["products", "Products"], ["merchandising", "Weather & Events"], ["customers", "Customers"], ["riders", "Riders"], ["payments", "Payments"]];
    var nav = '<nav class="admin-side" aria-label="Dashboard sections">' + tabs.map(function(t){
      var badge = t[0] === "orders" ? '<span class="pending-order-count admin-order-count" ' + (attention ? '' : 'hidden') + '>' + (attention > 99 ? "99+" : attention) + '</span>' : '';
      return '<button class="admin-tab' + (t[0] === tab ? ' active' : '') + '" onclick="App.setTab(\'' + t[0] + '\')">' + t[1] + badge + '</button>';
    }).join("") + '</nav>';
    var body = "";
    if (tab === "orders"){
      body = adminOrdersBody();
    } else if (tab === "products"){
      var productCreateForm = '<div class="admin-card product-create-card"><strong>Add a flower</strong><p class="sub">Use an image file saved in the flowers folder, for example flowers/whiteroses.jpg. Spaces in image filenames are okay. New flowers start with 0 stock; set the quantity below after adding.</p>' +
        '<div class="product-create-form product-create-form--new"><label>Flower name<input id="new-product-name" type="text" maxlength="80" autocomplete="off"></label>' +
        '<label>Image location<input id="new-product-image" type="text" placeholder="flowers/flower.jpg" autocomplete="off"></label>' +
        '<label>Price ' + CURRENCY + '<input id="new-product-price" type="number" min="0" max="100000" step="0.01"></label>' +
        '<label class="product-field-description">Description<textarea id="new-product-description" maxlength="300" rows="3"></textarea></label>' +
        '<button class="btn" onclick="App.addProduct()">Add flower</button></div></div>';
      body = productCreateForm + '<div class="admin-grid">' + db.products.map(function(p){
        var f = { id: p.id, name: p.name, description: p.description, imagePath: p.imagePath, price: p.price, qty: p.qty, available: p.available, stock: p.stock }, look = flowerById(p.id);
        var on = stockQty(f) > 0;
        return '<div class="admin-card product-edit-card"><div class="row"><span class="admin-prod">' + (look ? flowerPhoto(look, "admin-thumb", true, false) : '') + '<strong>' + esc(f.name) + '</strong></span><span class="stock-state ' + (on ? 'in' : 'out') + '">' + (on ? 'In stock \u00b7 ' + esc(f.stock) : 'Out of stock') + '</span></div>' +
          '<div class="product-create-form product-create-form--edit"><label>Flower name<input id="p-name-' + f.id + '" type="text" maxlength="80" value="' + esc(f.name) + '"></label>' +
          '<label>Image location<input id="p-image-' + f.id + '" type="text" maxlength="255" value="' + esc(f.imagePath || '') + '"></label>' +
          '<label>Price ' + CURRENCY + ' <input id="p-price-' + f.id + '" type="number" min="0" step="0.01" value="' + f.price + '"></label>' +
          '<label>Qty <input id="p-qty-' + f.id + '" type="number" min="0" step="1" value="' + (typeof f.qty === "number" ? f.qty : 0) + '"></label>' +
          '<label>Status <select id="p-avail-' + f.id + '"><option value="1"' + (f.available !== false ? ' selected' : '') + '>In stock</option><option value="0"' + (f.available === false ? ' selected' : '') + '>Out of stock</option></select></label>' +
          '<button type="button" class="product-description-toggle" aria-expanded="false" aria-controls="p-description-field-' + f.id + '" onclick="App.toggleProductDescription(' + f.id + ', this)">Description</button>' +
          '<label class="product-field-description" id="p-description-field-' + f.id + '" hidden>Description<textarea id="p-description-' + f.id + '" maxlength="300" rows="3">' + esc(f.description || '') + '</textarea></label>' +
          '<div class="product-edit-actions"><button class="btn" onclick="App.saveProduct(' + f.id + ')">Save changes</button><button class="logout-btn product-delete-btn" onclick="App.deleteProduct(' + f.id + ')">Delete flower</button></div></div>' +
          (f.available !== false && f.qty === 0 ? '<p class="sub" style="margin:8px 0 0">Quantity is 0, so customers see this flower as Out of stock.</p>' : '') + '</div>';
      }).join("") + '</div>';
    } else if (tab === "merchandising"){
      var merchandising = state.merchandising;
      var weatherOptions = '<option value=""' + (!merchandising.weather ? ' selected' : '') + '>No weather picks</option>' +
        WEATHER_PRESETS.map(function(weather){
          return '<option value="' + weather.id + '"' + (merchandising.weather === weather.id ? ' selected' : '') + '>' + esc(weather.label) + '</option>';
        }).join("");
      var weatherFlowersBody = WEATHER_PRESETS.map(function(weather){
        var selectedFlowers = merchandising.weatherFlowers[weather.id] || weather.recommendedFlowerIds;
          return '<div class="admin-card recommendation-panel weather-' + esc(weather.id) + '"><div class="row"><strong>' + esc(weather.label) + ' flowers</strong></div><div class="flower-choice-grid">' +
          db.products.map(function(product){
            return '<label><input type="checkbox" name="weather-flower-' + weather.id + '" value="' + product.id + '"' + (selectedFlowers.indexOf(product.id) >= 0 ? ' checked' : '') + '> ' + esc(product.name) + '</label>';
          }).join("") + '</div><div class="admin-actions"><button class="btn" onclick="App.saveWeatherFlowers(\'' + weather.id + '\')">Save ' + esc(weather.label) + ' flowers</button></div></div>';
      }).join("");
      var eventsBody = OCCASIONS.slice().sort(function(a, b){
        return a.startMonth - b.startMonth || a.startDay - b.startDay;
      }).map(function(event){
        var chosen = merchandising.eventFlowers[event.id] || event.recommendedFlowerIds;
        var dateText = event.startMonth === event.endMonth && event.startDay === event.endDay ?
          event.startMonth + "/" + event.startDay : event.startMonth + "/" + event.startDay + "–" + event.endMonth + "/" + event.endDay;
        return '<div class="admin-card recommendation-panel event-panel event-' + esc(event.id) + '"><div class="row"><strong>' + esc(event.name) + '</strong><span class="sub">' + esc(dateText) + '</span></div>' +
          '<p class="sub">' + esc(event.message) + '</p><div class="flower-choice-grid">' +
          db.products.map(function(product){
            return '<label><input type="checkbox" name="event-flower-' + event.id + '" value="' + product.id + '"' + (chosen.indexOf(product.id) >= 0 ? ' checked' : '') + '> ' + esc(product.name) + '</label>';
          }).join("") +
          '</div><div class="admin-actions"><button class="btn" onclick="App.saveEventFlowers(\'' + event.id + '\')">Save event flowers</button></div></div>';
      }).join("");
      body = '<div class="admin-card"><div class="row"><strong>Weather picks</strong></div><div class="admin-actions"><label>Storefront weather <select id="weather-choice">' + weatherOptions + '</select></label><button class="btn" onclick="App.saveWeather()">Save weather setting</button></div></div>' +
        '<h3>Weather flowers</h3><p class="sub">Choose which flowers customers see for each weather recommendation.</p>' + weatherFlowersBody +
        '<h3>Events</h3><p class="sub">Events appear automatically during their date ranges: Valentine’s Day February 11–15, Mother’s Day May 1–14, Halloween October 25–November 2, Christmas December 22–26, and New Year December 28–January 1.</p>' + eventsBody;
    } else if (tab === "riders"){
      var riderForm = '<div class="admin-card"><strong>Add a delivery rider</strong><p class="sub">Add a rider’s name and phone number so they can be assigned to delivery orders.</p>' +
        '<div class="product-create-form"><label>First name<input id="new-rider-fname" type="text" maxlength="40" autocomplete="given-name"></label>' +
        '<label>Middle name <span class="sub">(optional)</span><input id="new-rider-mname" type="text" maxlength="40" autocomplete="additional-name"></label>' +
        '<label>Last name<input id="new-rider-lname" type="text" maxlength="40" autocomplete="family-name"></label>' +
        '<label>Phone number<input id="new-rider-phone" type="tel" inputmode="numeric" pattern="09[0-9]{9}" minlength="11" maxlength="11" placeholder="09XXXXXXXXX" autocomplete="tel" title="Enter an 11-digit Philippine mobile number starting with 09"></label>' +
        '<button class="btn" onclick="App.addRider()">Add rider</button></div></div>';
      body = riderForm + (db.riders.length ? '<div class="admin-grid">' + db.riders.map(function(rider){
        var assignedOrder = db.orders.filter(function(order){
          return Number(order.riderId) === Number(rider.id) && order.fulfillment === "delivery" && orderCategory(order) === "ongoing";
        })[0];
        var availability = assignedOrder ? "Unavailable" : "Available";
        return '<div class="admin-card"><div class="row"><div><strong>' + esc(rider.name) + '</strong><p class="sub">' + esc(rider.phone) + '</p>' +
          (assignedOrder ? '<p class="sub">Assigned to ' + esc(assignedOrder.code) + '</p>' : '') + '</div>' +
          '<span class="stock-state ' + (assignedOrder ? 'out' : 'in') + '">' + availability + '</span>' +
          '<button class="logout-btn product-delete-btn" onclick="App.deleteRider(' + rider.id + ')">Delete</button></div></div>';
      }).join("") + '</div>' : '<p class="sub">No riders added yet.</p>');
    } else if (tab === "payments"){
      body = adminPaymentsBody();
    } else {
      var cs = db.users.filter(function(u){ return u.role !== "admin"; });
      body = cs.length ? '<div class="admin-grid">' + cs.map(function(u, ci){
        var n = db.orders.filter(function(o){ return o.email === u.email; }).length;
        return '<div class="admin-card"><div class="row"><strong>' + esc(u.name) + '</strong><span class="sub">' + n + ' order' + (n === 1 ? '' : 's') + '</span></div><p class="sub">' + esc(u.email) + '</p></div>';
      }).join("") + '</div>' : '<p class="sub">No customers have registered yet.</p>';
    }
    return '<div class="admin-shell"><div class="admin-head"><div><h1 class="display">Dashboard</h1><p class="sub">Welcome back, ' + esc((state.userName || "Admin").split(" ")[0]) + '. Here is what is happening in the shop.</p></div></div>' +
      adminStats() +
      '<div class="admin-layout">' + nav + '<section class="admin-content"><div class="admin-content-head"><h2>' + (tab === "merchandising" ? "Weather & Events" : tab.charAt(0).toUpperCase() + tab.slice(1)) + '</h2><p class="sub">' + help + '</p></div>' + body + '</section></div></div>';
  }
    return {
      screenAdmin: screenAdmin,
      actions: {
    setTab: function(t){ state.adminTab = t; render(); },
    setAdminOrderFilter: function(filter){
      if (["verify", "ongoing", "completed", "cancelled"].indexOf(filter) < 0) return;
      state.adminOrderFilter = filter;
      render();
    },
    saveWeather: function(){
      var weather = document.getElementById("weather-choice").value;
      api("PUT", "/api/admin/weather", { weather: weather }).then(loadAdmin).then(function(){ render(); notify("success", weather ? "The shop now recommends " + weather + "-day flowers." : "Weather picks are switched off.", "Weather setting saved"); }).catch(showErr);
    },
    saveWeatherFlowers: function(weather){
      var selected = document.querySelectorAll('input[name="weather-flower-' + weather + '"]:checked');
      var flowerIds = Array.prototype.map.call(selected, function(input){ return parseInt(input.value, 10); });
      api("PUT", "/api/admin/weather-flowers/" + weather, { flowerIds: flowerIds }).then(loadAdmin).then(function(){ render(); notify("success", "Flowers for the " + weather + " recommendation were updated.", "Weather flowers saved"); }).catch(showErr);
    },
    saveEventFlowers: function(eventId){
      var selected = document.querySelectorAll('input[name="event-flower-' + eventId + '"]:checked');
      var flowerIds = Array.prototype.map.call(selected, function(input){ return parseInt(input.value, 10); });
      api("PUT", "/api/admin/events/" + eventId, { flowerIds: flowerIds }).then(loadAdmin).then(function(){ render(); notify("success", "The featured flowers for this event were updated.", "Event flowers saved"); }).catch(showErr);
    },
    setStatus: function(code, status){
      api("PATCH", "/api/admin/orders/" + code, { status: status }).then(loadAdmin).then(function(){ render(); notify("success", "Order " + code + " is now " + status + ".", "Order updated"); }).catch(showErr);
    },
    cancelOrder: function(code){
      showConfirm("Cancel order " + code + "? The stems go back into stock. If the customer already paid with GCash, remember to refund them.", function(){
        api("PATCH", "/api/admin/orders/" + code, { status: "Cancelled" }).then(loadAdmin).then(function(){ render(); notify("success", "Order " + code + " was cancelled and its stock was returned.", "Order cancelled"); }).catch(showErr);
      }, "Cancel this order?", "Cancel order");
    },
    verifyPayment: function(code){
      var field = document.getElementById("pay-note-" + code), note = field ? field.value.trim() : "";
      showConfirm("Confirm that the GCash payment for " + code + " arrived? Only verify it after you have seen the reference number and the exact amount in your GCash transactions.", function(){
        api("PUT", "/api/admin/orders/" + encodeURIComponent(code) + "/payment", { action: "verify", note: note }).then(loadAdmin).then(function(){
          render(); notify("success", "The GCash payment for " + code + " is verified. The customer was notified, and you can now prepare the order.", "Payment verified", { duration: 7000 });
        }).catch(showErr);
      }, "Verify this payment?", "Verify payment");
    },
    rejectPayment: function(code){
      var field = document.getElementById("pay-note-" + code), note = field ? field.value.trim() : "";
      showConfirm("Reject the GCash payment for " + code + "? The order will be cancelled and its stock returned. The customer will see your note.", function(){
        api("PUT", "/api/admin/orders/" + encodeURIComponent(code) + "/payment", { action: "reject", note: note }).then(loadAdmin).then(function(){
          render(); notify("warning", "Order " + code + " was cancelled and its stock was returned.", "Payment rejected", { duration: 7000 });
        }).catch(showErr);
      }, "Reject this payment?", "Reject payment");
    },
    viewProof: function(code){
      apiBlob("/api/admin/orders/" + encodeURIComponent(code) + "/proof").then(function(blob){
        openLightbox(URL.createObjectURL(blob), "Receipt screenshot for " + code);
      }).catch(showErr);
    },
    saveGcashSettings: function(){
      var name = document.getElementById("gcash-name").value.trim(), number = document.getElementById("gcash-number").value.trim();
      if (!name){ showWarning("Enter the name shown on the GCash account.", "Account name needed"); return; }
      api("PUT", "/api/admin/payment-settings", { name: name, number: number }).then(function(info){
        state.payInfo = info; render(); notify("success", "Customers will now see " + info.name + (info.number ? " (" + info.number + ")" : "") + " beside the QR code.", "GCash details saved");
      }).catch(showErr);
    },
    pickQr: function(input){
      var file = input.files && input.files[0]; input.value = "";
      if (!file) return;
      if (!/^image\/(png|jpeg|webp)$/.test(file.type)){ notify("warning", "Please choose a PNG, JPG or WebP picture of your GCash QR code.", "Unsupported file"); return; }
      shrinkImage(file, 1400, "image/png").then(function(dataUrl){
        if (dataUrl.length > 2600000){ notify("warning", "That image is too large even after shrinking. Please use a smaller screenshot of the QR code.", "Image too large"); return; }
        state.qrDraft = dataUrl; render();
      }).catch(showErr);
    },
    cancelQr: function(){ state.qrDraft = ""; render(); },
    saveQr: function(){
      if (!state.qrDraft) return;
      api("POST", "/api/admin/payment-qr", { image: state.qrDraft }).then(function(info){
        state.payInfo = info; state.qrDraft = ""; render(); notify("success", "Customers now scan your QR code at checkout.", "GCash QR code updated");
      }).catch(showErr);
    },
    saveProduct: function(id){
      var name = document.getElementById("p-name-" + id).value.trim();
      var imagePath = document.getElementById("p-image-" + id).value.trim();
      var description = document.getElementById("p-description-" + id).value.trim();
      var price = parseFloat(document.getElementById("p-price-" + id).value);
      var qty = parseInt(document.getElementById("p-qty-" + id).value, 10);
      var available = document.getElementById("p-avail-" + id).value === "1";
      if (!name || !imagePath || isNaN(price) || price < 0 || isNaN(qty) || qty < 0){ showWarning("Enter a flower name, image, valid price, and quantity.", "Check the flower details"); return; }
      api("PUT", "/api/admin/products/" + id, { name: name, description: description, imagePath: imagePath, price: price, qty: qty, available: available }).then(loadProducts).then(loadAdmin).then(function(){ render(); notify("success", name + " was updated.", "Flower saved"); }).catch(showErr);
    },
    toggleProductDescription: function(id, button){
      var field = document.getElementById("p-description-field-" + id);
      if (!field) return;
      field.hidden = !field.hidden;
      button.setAttribute("aria-expanded", field.hidden ? "false" : "true");
    },
    addProduct: function(){
      var name = document.getElementById("new-product-name").value.trim();
      var imagePath = document.getElementById("new-product-image").value.trim();
      var description = document.getElementById("new-product-description").value.trim();
      var price = parseFloat(document.getElementById("new-product-price").value);
      if (!name || !imagePath || isNaN(price) || price < 0){ showWarning("Enter the flower name, image location, and a valid price.", "Complete all flower details"); return; }
      api("POST", "/api/admin/products", { name: name, description: description, imagePath: imagePath, price: price })
        .then(loadProducts).then(loadAdmin).then(function(){ render(); notify("success", name + " is now in the shop.", "Flower added"); }).catch(showErr);
    },
    addRider: function(){
      var fname = document.getElementById("new-rider-fname").value.trim();
      var mname = document.getElementById("new-rider-mname").value.trim();
      var lname = document.getElementById("new-rider-lname").value.trim();
      var name = [fname, mname, lname].filter(Boolean).join(" ");
      var phone = document.getElementById("new-rider-phone").value.trim();
      if (!fname || !lname || !/^09[0-9]{9}$/.test(phone)){
        showWarning("Enter the rider’s first and last name, and an 11-digit Philippine mobile number starting with 09.", "Check rider details");
        return;
      }
      var normalizedPhone = phone;
      if (db.riders.some(function(rider){ return rider.phone.replace(/\D/g, "") === normalizedPhone; })){
        showWarning("A rider with this phone number already exists.", "Duplicate rider phone");
        return;
      }
      api("POST", "/api/admin/riders", { fname: fname, mname: mname, lname: lname, phone: phone }).then(loadAdmin).then(function(){ render(); notify("success", name + " can now be assigned to delivery orders.", "Rider saved"); }).catch(showErr);
    },
    deleteRider: function(id){
      var rider = db.riders.filter(function(item){ return Number(item.id) === Number(id); })[0];
      if (!rider) return;
      showConfirm("Permanently delete " + rider.name + "? They will no longer be available for new assignments. Existing orders will keep the saved rider name and phone.", function(){
        api("DELETE", "/api/admin/riders/" + encodeURIComponent(id)).then(loadAdmin).then(function(){
          render(); notify("success", rider.name + " was removed from available riders.", "Rider removed");
        }).catch(showErr);
      }, "Delete this rider?", "Delete rider");
    },
    assignRider: function(code){
      var input = document.getElementById("rider-select-" + code);
      if (!input) return;
      var riderId = input.value ? Number(input.value) : null;
      api("PUT", "/api/admin/orders/" + encodeURIComponent(code) + "/rider", { riderId: riderId }).then(loadAdmin).then(function(){ render(); notify("success", riderId ? "A rider was assigned to order " + code + "." : "The rider was removed from order " + code + ".", "Rider updated"); }).catch(showErr);
    },
    deleteProduct: function(id){
      var product = db.products.filter(function(item){ return item.id === id; })[0];
      var name = product ? product.name : "this flower";
      showConfirm("Permanently remove " + name + " from the flower database? Existing order records will keep the flower name and price, but it will no longer be linked to the flower. Customers with it in their cart will be told it is no longer available.", function(){
        api("DELETE", "/api/admin/products/" + id)
          .then(loadProducts).then(loadAdmin).then(function(){ render(); notify("success", name + " was removed from the shop.", "Flower removed"); }).catch(showErr);
      }, "Remove this flower?", "Remove flower");
    },
      }
    };
  };
})();
